DROP TABLE IF EXISTS libri_librerie CASCADE;
DROP TABLE IF EXISTS valutazioni CASCADE;
DROP TABLE IF EXISTS suggerimenti CASCADE;
DROP TABLE IF EXISTS librerie CASCADE;
DROP TABLE IF EXISTS libri CASCADE;
DROP TABLE IF EXISTS utenti CASCADE;

CREATE TABLE utenti (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cognome VARCHAR(100) NOT NULL,
    codice_fiscale VARCHAR(16) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
);

CREATE TABLE libri (
    id SERIAL PRIMARY KEY,
    titolo VARCHAR(255) NOT NULL,
    autore VARCHAR(255) NOT NULL,
    descrizione TEXT,
    categoria VARCHAR(100),
    editore VARCHAR(255),
    mese_pubblicazione VARCHAR(20),
    anno_pubblicazione INT,
    CONSTRAINT titolo_autore_unique UNIQUE (titolo, autore)
);

CREATE TABLE suggerimenti (
    id SERIAL PRIMARY KEY,
    id_utente INT NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    letto VARCHAR(255) NOT NULL,
    suggerito VARCHAR(255) NOT NULL
);

CREATE TABLE librerie (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    id_utente INT NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    UNIQUE(nome, id_utente)
);

CREATE TABLE libri_librerie (
    id_libreria INT REFERENCES librerie(id) ON DELETE CASCADE,
    id_libro INT REFERENCES libri(id) ON DELETE CASCADE,
    PRIMARY KEY (id_libreria, id_libro)
);

CREATE TABLE valutazioni (
    id SERIAL PRIMARY KEY,
    id_libro INT NOT NULL REFERENCES libri(id) ON DELETE CASCADE,
    id_utente INT NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    stile INT,
    nota_stile TEXT,
    contenuto INT,
    nota_contenuto TEXT,
    gradevolezza INT,
    nota_gradevolezza TEXT,
    originalita INT,
    nota_originalita TEXT,
    edizione INT,
    nota_edizione TEXT,
    voto_finale INT,
    nota_generale TEXT,
    UNIQUE(id_libro, id_utente)
);
