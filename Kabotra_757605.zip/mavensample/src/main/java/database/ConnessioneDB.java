package database;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class ConnessioneDB {

    private static String URL;
    private static String USER;
    private static String PASSWORD;

    private static final String CONFIG_FILE = "config.properties";

    /**
     * Carica i parametri di connessione da file o li chiede all'utente.
     */
    public static void setupConnectionParams() {
        Properties props = new Properties();
        File file = new File(CONFIG_FILE);

        if (file.exists()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                props.load(fis);
                String host = props.getProperty("host");
                String port = props.getProperty("port");
                String dbName = props.getProperty("db");
                USER = props.getProperty("user");
                PASSWORD = props.getProperty("password");

                URL = "jdbc:postgresql://" + host + ":" + port + "/" + dbName;
                System.out.println("✅ Parametri di connessione caricati da file.");
                return;
            } catch (IOException e) {
                System.err.println("Errore nella lettura di config.properties");
            }
        }

        // Se il file non esiste o fallisce il caricamento, chiedi all’utente
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== CONFIGURAZIONE CONNESSIONE DB ===");

        System.out.print("Host (es. localhost): ");
        String host = scanner.nextLine().trim();

        System.out.print("Porta (es. 5432): ");
        String port = scanner.nextLine().trim();

        System.out.print("Nome Database: ");
        String dbName = scanner.nextLine().trim();

        System.out.print("Username: ");
        USER = scanner.nextLine().trim();

        System.out.print("Password: ");
        PASSWORD = scanner.nextLine();

        URL = "jdbc:postgresql://" + host + ":" + port + "/" + dbName;

        // Salva nel file
        props.setProperty("host", host);
        props.setProperty("port", port);
        props.setProperty("db", dbName);
        props.setProperty("user", USER);
        props.setProperty("password", PASSWORD);

        try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
            props.store(fos, "Configurazione DB utente");
            System.out.println("📁 Parametri salvati in config.properties.");
        } catch (IOException e) {
            System.err.println("Errore nel salvataggio dei parametri.");
        }
    }

    /**
     * Restituisce la connessione configurata.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
