/*Grampa, Marco, 758701, Varese, (System architect)
Kabotra, Rahul, 757605, Varese, (Project manager)
Morena, Matteo, 756150, Varese, (Document & quality manager)
Colombo, Gianluca, 757634, Varese, (Design manager)*/
package controllers;

import java.io.IOException;
import java.util.ArrayList;

import Base.Messaggio;
import Base.RepositoryLibri;
import Base.Utenti;
import Networking.Client;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * Controller per la schermata di login.
 * <p>
 * Gestisce l'autenticazione dell'utente tramite comunicazione con il server.
 * In caso di successo, salva l'oggetto {@link Utenti} autenticato e chiude la finestra di login.
 * </p>
 */
public class LoginController {

    /** Campo di input per lo username dell'utente */
    @FXML private TextField userIdField;

    /** Campo di input per la password dell'utente */
    @FXML private PasswordField passwordField;

    /** Oggetto Utenti autenticato dopo il login */
    private Utenti utenteAutenticato;

    /** Oggetto client per la comunicazione col server */
    private Client client;

    /**
     * Imposta il client per la comunicazione con il server.
     *
     * @param client il client socket utilizzato per inviare richieste
     */
    public void setClient(Client client) {
        this.client = client;
    }

    /**
     * Restituisce l'utente autenticato dopo un login andato a buon fine.
     *
     * @return l'oggetto {@link Utenti} autenticato
     */
    public Utenti getUtente() {
        return utenteAutenticato;
    }

    /**
     * Gestisce l'evento di login: recupera i dati inseriti, invia la richiesta al server
     * e gestisce la risposta autenticando l'utente o mostrando un errore.
     */
    @FXML
    private void handleLogin() {
        String userId = userIdField.getText().trim();
        String password = passwordField.getText().trim();

        // Controllo preliminare dei campi
        if (userId.isEmpty() || password.isEmpty()) {
            showAlert("Errore", "Inserisci userId e password.");
            return;
        }

        try {
            // Crea e invia il messaggio di login al server
            Messaggio richiesta = new Messaggio("login", new String[]{userId, password});
            Messaggio risposta = client.inviaRichiesta(richiesta);
            Object contenuto = risposta.getContenuto();

            if (contenuto instanceof Utenti utente) {
                // Login riuscito
                this.utenteAutenticato = utente;

                // Chiudi la finestra di login, la home verrà gestita da MainController
                Stage currentStage = (Stage) userIdField.getScene().getWindow();
                currentStage.close();

            } else {
                // Login fallito
                showAlert("Login fallito", "Credenziali errate o server non disponibile.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Errore", "Errore durante il login: " + e.getMessage());
        }
    }

    /**
     * Mostra una finestra di dialogo informativa con il titolo e il messaggio specificati.
     *
     * @param titolo    titolo della finestra
     * @param messaggio messaggio da mostrare
     */
    private void showAlert(String titolo, String messaggio) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titolo);
        alert.setHeaderText(null);
        alert.setContentText(messaggio);
        alert.showAndWait();
    }
}
