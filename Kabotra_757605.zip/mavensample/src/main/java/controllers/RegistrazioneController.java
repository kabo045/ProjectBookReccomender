/*Grampa, Marco, 758701, Varese, (System architect)
Kabotra, Rahul, 757605, Varese,  (Project manager)
Morena, Matteo, 756150, Varese, (Document & quality manager)
Colombo, Gianluca, 757634, Varese,  (Design manager)*/
package controllers;

import Base.GestioneUtenti;
import Base.Utenti;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 * Controller associato alla finestra di registrazione utente.
 * <p>
 * Verifica i dati inseriti nel form, effettua le validazioni necessarie
 * (sintattiche e logiche) e, se tutto è corretto, registra l’utente nel sistema.
 * </p>
 */
public class RegistrazioneController {

    // Campi di input definiti nel file FXML
    @FXML private TextField nomeField;
    @FXML private TextField cognomeField;
    @FXML private TextField cfField;
    @FXML private TextField emailField;
    @FXML private TextField userIdField;
    @FXML private PasswordField passwordField;

    /**
     * Gestisce il processo di registrazione quando l’utente preme il pulsante.
     * Valida i campi e invia i dati alla logica di business.
     */
    @FXML
    private void handleRegistrazione() {
        // Recupero dei dati dai campi
        String nome = nomeField.getText().trim();
        String cognome = cognomeField.getText().trim();
        String cf = cfField.getText().trim().toUpperCase();
        String email = emailField.getText().trim();
        String userId = userIdField.getText().trim();
        String password = passwordField.getText().trim();

        // Verifica che tutti i campi siano compilati
        if (nome.isEmpty() || cognome.isEmpty() || cf.isEmpty() ||
            email.isEmpty() || userId.isEmpty() || password.isEmpty()) {
            showAlert("Errore", "Compila tutti i campi.");
            return;
        }

        // Validazione nome
        if (!GestioneUtenti.nomeValido(nome)) {
            showAlert("Errore", "Nome non valido. Usa solo lettere e almeno 2 caratteri.");
            return;
        }

        // Validazione cognome
        if (!GestioneUtenti.nomeValido(cognome)) {
            showAlert("Errore", "Cognome non valido. Usa solo lettere e almeno 2 caratteri.");
            return;
        }

        // Validazione codice fiscale
        if (!Utenti.validaCodiceFiscale(cf)) {
            showAlert("Errore", "Codice fiscale non valido.");
            return;
        }

        // Validazione email
        if (!Utenti.emailValida(email)) {
            showAlert("Errore", "Email non valida.");
            return;
        }

        // Verifica se userId già registrato
        if (GestioneUtenti.utenteEsiste(userId)) {
            showAlert("Errore", "User ID già in uso.");
            return;
        }

        // Verifica se codice fiscale già presente
        if (GestioneUtenti.utenteEsistePerCF(cf)) {
            showAlert("Errore", "Codice fiscale già registrato.");
            return;
        }

        // Se tutte le verifiche sono superate, procede con la registrazione
        boolean successo = GestioneUtenti.registraDiretto(nome, cognome, cf, email, userId, password);

        if (successo) {
            showAlert("Registrazione", "Registrazione avvenuta con successo!");
            // Chiude la finestra di registrazione
            ((Stage) userIdField.getScene().getWindow()).close();
        } else {
            showAlert("Errore", "Errore durante il salvataggio.");
        }
    }

    /**
     * Mostra una finestra di dialogo informativa.
     *
     * @param titolo    Titolo della finestra
     * @param messaggio Messaggio da visualizzare
     */
    private void showAlert(String titolo, String messaggio) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titolo);
        alert.setContentText(messaggio);
        alert.showAndWait();
    }
}
