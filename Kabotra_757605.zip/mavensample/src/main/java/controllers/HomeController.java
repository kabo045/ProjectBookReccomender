/*Grampa, Marco, 758701, Varese, (Systen architect)
Kabotra, Rahul, 757605, Varese,  (Project manager)
Morena, Matteo, 756150, Varese, (Document & quality manager)
Colombo, Gianluca, 757634, Varese,  (Design manager)*/
package controllers;

import Base.*;
import Networking.Client;
import database.ConnessioneDB;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;

/**
 * Controller principale per la schermata "Home" dell'applicazione.
 * <p>
 * Gestisce le operazioni dell'utente relative a:
 * <ul>
 *   <li>Gestione delle librerie (creazione, eliminazione, visualizzazione)</li>
 *   <li>Gestione dei libri (aggiunta, eliminazione, ricerca, visualizzazione)</li>
 *   <li>Valutazioni (inserimento, visualizzazione, media)</li>
 *   <li>Suggerimenti (inserimento, consultazione)</li>
 *   <li>Logout</li>
 * </ul>
 * </p>
 * Utilizza JavaFX per l'interfaccia grafica e comunica con il backend tramite
 * {@link Client} e {@link RepositoryLibri}.
 */

public class HomeController {

    @FXML private Label welcomeLabel;
    @FXML private StackPane contenutoArea;
    private Client client;
    private Utenti utente;
    private RepositoryLibri repositoryLibri;
    private int proprietarioId;


    public void setRepository(RepositoryLibri repositoryLibri) {
        this.repositoryLibri = repositoryLibri;
        this.repositoryLibri.caricaLibri(); // <── IMPORTANTE!
    }


    public void setClient(Client client) {
        this.client = client;
    }

    public void inizializzaUtente(Utenti utente) {
        this.utente = utente;
        welcomeLabel.setText("Benvenuto, " + utente.getUserId());
        this.proprietarioId = GestioneLibreria.getIdUtenteDaUsername(utente.getUserId());
    }

    private void setContenuto(javafx.scene.Node nodo) {
        contenutoArea.getChildren().clear();
        contenutoArea.getChildren().add(nodo);
    }

    private VBox creaVBoxStandard(String titolo) {
        VBox vbox = new VBox(10);
        vbox.setStyle("-fx-padding: 15; -fx-background-color: #ffffff;");
        if (titolo != null && !titolo.isBlank()) {
            Label label = new Label(titolo);
            label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
            vbox.getChildren().add(label);
        }
        return vbox;
    }

    private TextField creaCampo(String prompt) {
        TextField tf = new TextField();
        tf.setPromptText(prompt);
        return tf;
    }

    private void alert(String titolo, String messaggio) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titolo);
        alert.setHeaderText(null);
        alert.setContentText(messaggio);
        alert.showAndWait();
    }
    @FXML
    /**
     * Visualizza l'interfaccia per eliminare una libreria dell'utente.
     */
    private void showEliminaLibreria() {
        VBox vbox = creaVBoxStandard("Elimina una Libreria");

        ComboBox<Libreria> selezioneLibreria = new ComboBox<>();
        List<Libreria> librerieUtente = GestioneLibreria.caricaLibrerie().stream()
            .filter(l -> l.getProprietarioId() == proprietarioId)
            .collect(Collectors.toList());
        selezioneLibreria.getItems().addAll(librerieUtente);
        selezioneLibreria.setPromptText("Seleziona la libreria da eliminare");

        Button eliminaBtn = new Button("Elimina Libreria");
        eliminaBtn.setOnAction(e -> {
            Libreria selezionata = selezioneLibreria.getValue();
            if (selezionata == null) {
                alert("Errore", "Seleziona una libreria.");
                return;
            }

            Alert conferma = new Alert(Alert.AlertType.CONFIRMATION);
            conferma.setTitle("Conferma eliminazione");
            conferma.setHeaderText("Vuoi davvero eliminare la libreria?");
            conferma.setContentText("Tutti i riferimenti ai libri verranno rimossi.");

            Optional<ButtonType> result = conferma.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                GestioneLibreria.eliminaLibreria(selezionata.getNome(), utente.getUserId());
                alert("Successo", "Libreria eliminata.");
            }
        });

        vbox.getChildren().addAll(selezioneLibreria, eliminaBtn);
        setContenuto(vbox);
    }

    @FXML
    /**
     * Visualizza l'interfaccia per eliminare un libro da una libreria.
     */
    private void showEliminaLibroDaLibreria() {
        VBox vbox = creaVBoxStandard("Elimina Libro da Libreria");

        ComboBox<Libreria> selezioneLibreria = new ComboBox<>();
        List<Libreria> librerieUtente = GestioneLibreria.caricaLibrerie().stream()
            .filter(l -> l.getProprietarioId() == proprietarioId)
            .collect(Collectors.toList());
        selezioneLibreria.getItems().addAll(librerieUtente);
        selezioneLibreria.setPromptText("Seleziona una libreria");

        TextField campoTitoloLibro = creaCampo("Titolo del libro da eliminare");

        Button eliminaBtn = new Button("Elimina");
        eliminaBtn.setOnAction(e -> {
            Libreria selezionata = selezioneLibreria.getValue();
            String titoloLibro = campoTitoloLibro.getText().trim();

            if (selezionata == null || titoloLibro.isEmpty()) {
                alert("Errore", "Seleziona una libreria e inserisci un titolo.");
                return;
            }
            try {
                GestioneLibreria.eliminaLibroDaLibreria(
                    selezionata.getNome(),
                    utente.getUserId(),
                    titoloLibro
                );
                alert("Successo", "Libro eliminato dalla libreria.");
            } catch (Exception ex) {
                alert("Errore", "Errore durante l'eliminazione: " + ex.getMessage());
            }
        });

        // Queste righe devono stare fuori dal setOnAction!
        vbox.getChildren().addAll(selezioneLibreria, campoTitoloLibro, eliminaBtn);
        setContenuto(vbox);
    }


    @FXML
    /**
     * Visualizza l'interfaccia per creare una nuova libreria.
     */
    private void showCreaLibreria() {
        VBox vbox = creaVBoxStandard("Crea Libreria");
        TextField nomeLibreria = creaCampo("Nome libreria");
        Button creaBtn = new Button("Crea");
        creaBtn.setOnAction(e -> {
            String nome = nomeLibreria.getText().trim();
            if (nome.isEmpty()) {
                alert("Errore", "Inserisci un nome valido.");
                return;
            }
            Libreria nuova = new Libreria(nome, proprietarioId);
            GestioneLibreria.registraLibreria(nuova);
            alert("Successo", "Libreria '" + nome + "' creata.");
        });
        vbox.getChildren().addAll(nomeLibreria, creaBtn);
        setContenuto(vbox);
    }
    @FXML
    /**
     * Visualizza l'interfaccia per aggiungere un nuovo libro a una libreria esistente.
     */
    private void showAggiungiLibro() {
        VBox vbox = creaVBoxStandard("Aggiungi Libro");

        ComboBox<Libreria> selezioneLibreria = new ComboBox<>();
        List<Libreria> librerieUtente = GestioneLibreria.caricaLibrerie().stream()
            .filter(l -> l.getProprietarioId() == proprietarioId)
            .collect(Collectors.toList());
        selezioneLibreria.getItems().addAll(librerieUtente);
        selezioneLibreria.setPromptText("Seleziona una libreria");

        TextField titolo = creaCampo("Titolo");
        TextField autore = creaCampo("Autore");
        TextField anno = creaCampo("Anno pubblicazione");
        Button aggiungi = new Button("Aggiungi");

        aggiungi.setOnAction(e -> {
            Libreria selezionata = selezioneLibreria.getValue();
            if (selezionata == null) {
                alert("Errore", "Seleziona una libreria.");
                return;
            }

            String titoloLibro = titolo.getText().trim();
            String autoreLibro = autore.getText().trim();
            int annoPubblicazione;

            try {
                annoPubblicazione = Integer.parseInt(anno.getText().trim());
            } catch (NumberFormatException ex) {
                alert("Errore", "Inserisci un anno valido.");
                return;
            }

            if (titoloLibro.isEmpty() || autoreLibro.isEmpty()) {
                alert("Errore", "Tutti i campi sono obbligatori.");
                return;
            }

            Libro nuovoLibro = new Libro(titoloLibro, autoreLibro, annoPubblicazione, "", "");
            repositoryLibri.aggiungiLibroALibreria(nuovoLibro, selezionata.getId()); // USA ID LIBRERIA
            alert("Successo", "Libro aggiunto con successo!");
        });

        vbox.getChildren().addAll(selezioneLibreria, titolo, autore, anno, aggiungi);
        setContenuto(vbox);
    }

    @FXML
    /**
     * Mostra tutte le librerie dell'utente e i relativi libri contenuti.
     */
    private void showVisualizzaLibrerie() {
        VBox vbox = creaVBoxStandard("Le Tue Librerie");
        List<Libreria> librerie = GestioneLibreria.caricaLibrerie().stream()
                .filter(l -> l.getProprietarioId() == proprietarioId)
                .collect(Collectors.toList());

        if (librerie.isEmpty()) {
            TextArea area = new TextArea("Nessuna libreria disponibile.");
            area.setEditable(false);
            vbox.getChildren().add(area);
        } else {
            for (Libreria l : librerie) {
                Label nome = new Label("\uD83D\uDCDA " + l.getNome() + " (" + l.getLibri().size() + " libri)");
                VBox listaLibri = new VBox(5);
                for (Libro libro : l.getLibri()) {
                    listaLibri.getChildren().add(new Label(" - " + libro.getTitolo() + " di " + libro.getAutori()));
                }
                VBox sezione = new VBox(5, nome, listaLibri);
                sezione.setStyle("-fx-padding: 10; -fx-background-color: #f0f0f0; -fx-border-color: #ccc;");
                vbox.getChildren().add(sezione);
            }
        }

        ScrollPane scroll = new ScrollPane(vbox);
        scroll.setFitToWidth(true);
        setContenuto(scroll);
    }

    @FXML
    /**
     * Permette la ricerca di libri in base al titolo.
     */
    private void showRicercaTitolo() {
        VBox vbox = creaVBoxStandard("🔍 Ricerca per Titolo");
        TextField campoTitolo = creaCampo("Titolo libro");
        Button cerca = new Button("Cerca");
        TextArea risultato = new TextArea();
        risultato.setEditable(false);

        cerca.setOnAction(e -> {
            String titolo = campoTitolo.getText().trim();
            if (titolo.isBlank()) {
                risultato.setText("  un titolo.");
                return;
            }

            List<Libro> trovati = repositoryLibri.cercaLibroPerTitolo(titolo);
            risultato.setText(trovati.isEmpty() ? "❌ Nessun libro trovato." : formatLibri(trovati));
        });

        vbox.getChildren().addAll(campoTitolo, cerca, risultato);
        setContenuto(vbox);
    }
    @FXML
    /**
     * Permette la ricerca di libri in base all'autore.
     */
    private void showRicercaAutore() {
        VBox vbox = creaVBoxStandard("Ricerca per Autore");
        TextField campoAutore = creaCampo("Autore");
        Button cerca = new Button("Cerca");
        TextArea risultato = new TextArea();
        risultato.setEditable(false);

        cerca.setOnAction(e -> {
            String autore = campoAutore.getText().trim();
            if (autore.isBlank()) {
                risultato.setText("Inserisci un autore.");
                return;
            }

            List<Libro> trovati = repositoryLibri.cercaLibroPerAutore(autore);
            risultato.setText(trovati.isEmpty() ? "Nessun libro trovato." : formatLibri(trovati));
        });

        vbox.getChildren().addAll(campoAutore, cerca, risultato);
        setContenuto(vbox);
    }

    @FXML
    /**
     * Permette la ricerca di libri per autore e anno di pubblicazione.
     */
    private void showRicercaAutoreAnno() {
        VBox vbox = creaVBoxStandard("ricerca per Autore e Anno");
        TextField campoAutore = creaCampo("Autore");
        TextField campoAnno = creaCampo("Anno");
        Button cerca = new Button("Cerca");
        TextArea risultato = new TextArea();
        risultato.setEditable(false);

        cerca.setOnAction(e -> {
            String autore = campoAutore.getText().trim();
            String annoText = campoAnno.getText().trim();

            if (autore.isBlank() || annoText.isBlank()) {
                risultato.setText("Inserisci autore e anno.");
                return;
            }

            try {
                int anno = Integer.parseInt(annoText);
                List<Libro> trovati = repositoryLibri.cercaLibroPerAutoreAnno(autore, anno);
                risultato.setText(trovati.isEmpty() ? "❌ Nessun libro trovato." : formatLibri(trovati));
            } catch (NumberFormatException ex) {
                alert("Errore", "❗ Inserisci un anno valido (numero intero).");
            }
        });

        vbox.getChildren().addAll(campoAutore, campoAnno, cerca, risultato);
        setContenuto(vbox);
    }
    private String formatLibri(List<Libro> libri) {
        StringBuilder sb = new StringBuilder();
        for (Libro libro : libri) {
            sb.append("📘 Titolo: ").append(libro.getTitolo()).append("\n")
              .append("✍️ Autore: ").append(libro.getAutori()).append("\n")
              .append("📅 Anno di pubblicazione: ").append(libro.getAnnoPubblicazione()).append("\n")
              .append("🏷️ Categoria: ").append(libro.getCategoria() != null ? libro.getCategoria() : "N/A").append("\n")
              .append("🏢 Editore: ").append(libro.getEditore() != null ? libro.getEditore() : "N/A").append("\n")
              .append("──────────────────────────────\n");
        }
        return sb.toString();
    }

    
    @FXML
    /**
     * Visualizza i dettagli di un libro basandosi sul titolo cercato.
     */
    private void showVisualizzaLibro() {
        VBox vbox = creaVBoxStandard("Esplora un libro");
        TextField campoTitolo = creaCampo("Titolo libro");
        Button visualizza = new Button("Visualizza");
        TextArea risultato = new TextArea(); 
        risultato.setEditable(false);

        visualizza.setOnAction(e -> {
            String titolo = campoTitolo.getText().trim();
            if (titolo.isEmpty()) {
                risultato.setText("Inserisci un titolo.");
                return;
            }

            List<Libro> corrispondenze = repositoryLibri.getLibri().stream()
                .filter(l -> l.getTitolo().toLowerCase().contains(titolo.toLowerCase()))
                .toList();

            if (corrispondenze.isEmpty()) {
                risultato.setText("Libro non trovato.");
            } else {
                StringBuilder sb = new StringBuilder();
                for (Libro libro : corrispondenze) {
                    sb.append("Titolo: ").append(libro.getTitolo()).append("\n")
                      .append("Autore: ").append(libro.getAutori()).append("\n")
                      .append("Anno: ").append(libro.getAnnoPubblicazione()).append("\n")
                      .append("Editore: ").append(libro.getEditore()).append("\n")
                      .append("Categoria: ").append(libro.getCategoria()).append("\n\n");
                }
                risultato.setText(sb.toString());
            }
        });

        vbox.getChildren().addAll(campoTitolo, visualizza, risultato);
        setContenuto(vbox);
    }

    @FXML
    /**
     * Visualizza le valutazioni inserite dall'utente.
     */
    private void showValutazioni() {
        VBox vbox = creaVBoxStandard("Le Tue Valutazioni");
        TextArea output = new TextArea();
        output.setEditable(false);

        // ricarica le valutazioni aggiornate
        repositoryLibri.caricaValutazioni();

        List<Valutazione> lista = repositoryLibri.getValutazioni().stream()
                .filter(v -> v.getUtenteId().equals(utente.getUserId()))
                .toList();

        String testo = lista.isEmpty() ? "Nessuna valutazione trovata." :
            lista.stream().map(v -> String.format(
                "📘 %s\n" +
                "Stile: %d (%s)\n" +
                "Contenuto: %d (%s)\n" +
                "Gradevolezza: %d (%s)\n" +
                "Originalità: %d (%s)\n" +
                "Edizione: %d (%s)\n" +
                "Voto Finale: %d (%s)\n",
                v.getTitoloLibro(), v.getStile(), v.getNotaStile(),
                v.getContenuto(), v.getNotaContenuto(),
                v.getGradevolezza(), v.getNotaGradevolezza(),
                v.getOriginalita(), v.getNotaOriginalita(),
                v.getEdizione(), v.getNotaEdizione(),
                v.getVotoFinale(), v.getNotaGenerale()
            )).collect(Collectors.joining("\n\n"));

        output.setText(testo);
        vbox.getChildren().add(output);
        setContenuto(vbox);
    }

    @FXML
    /**
     * Permette all'utente di inserire una valutazione per un libro.
     */
    private void showValutazioneLibro() {
        VBox vbox = creaVBoxStandard("Valuta un Libro");

        TextField campoTitolo = creaCampo("Titolo del libro");
        List<TextField> voti = List.of(
            creaCampo("Stile (1-10)"), creaCampo("Contenuto (1-10)"),
            creaCampo("Gradevolezza (1-10)"), creaCampo("Originalità (1-10)"),
            creaCampo("Edizione (1-10)"), creaCampo("Voto finale (1-10)")
        );
        List<TextField> note = List.of(
            creaCampo("Nota stile"), creaCampo("Nota contenuto"),
            creaCampo("Nota gradevolezza"), creaCampo("Nota originalità"),
            creaCampo("Nota edizione"), creaCampo("Nota generale")
        );

        Button invia = new Button("Invia valutazione");
        invia.setOnAction(e -> {
            try {
                String titolo = campoTitolo.getText().trim();
                if (titolo.isEmpty()) {
                    alert("Errore", "Inserisci il titolo del libro.");
                    return;
                }

                List<Integer> valori = new ArrayList<>();
                for (TextField tf : voti) {
                    int val = Integer.parseInt(tf.getText().trim());
                    if (val < 1 || val > 10) throw new NumberFormatException();
                    valori.add(val);
                }

                try (Connection conn = ConnessioneDB.getConnection()) {
                    Map<String, Integer> trovati = GestioneLibreria.cercaLibriFuzzy(conn, titolo);
                    if (trovati.isEmpty()) {
                        alert("Errore", "Libro non trovato.");
                        return;
                    }

                    String selezionato;
                    if (trovati.size() == 1) {
                        selezionato = trovati.keySet().iterator().next();
                    } else {
                        selezionato = chiediTitoloDaLista(trovati.keySet());
                        if (selezionato == null) return; // utente ha annullato
                    }

                    int idLibro = trovati.get(selezionato);

                    boolean ok = GestioneLibreria.inserisciValutazioneLibro(
                            utente.getUserId(), idLibro,
                            valori.get(0), note.get(0).getText().trim(),
                            valori.get(1), note.get(1).getText().trim(),
                            valori.get(2), note.get(2).getText().trim(),
                            valori.get(3), note.get(3).getText().trim(),
                            valori.get(4), note.get(4).getText().trim(),
                            valori.get(5), note.get(5).getText().trim()
                    );

                    if (ok) {
                        repositoryLibri.caricaValutazioni(); // <-- aggiornamento immediato
                        alert("Successo", "Valutazione inserita.");
                        Stream.concat(Stream.of(campoTitolo), Stream.concat(voti.stream(), note.stream()))
                              .forEach(TextField::clear);
                    } else {
                        alert("Errore", "Errore nell'inserimento.");
                    }
                }
            } catch (NumberFormatException ex) {
                alert("Errore", "I voti devono essere numeri tra 1 e 10.");
            } catch (Exception ex) {
                alert("Errore", "Errore: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        vbox.getChildren().addAll(Stream.concat(
            Stream.of(campoTitolo),
            Stream.concat(voti.stream(), note.stream())
        ).toList());
        vbox.getChildren().add(invia);
        setContenuto(vbox);
    }
    @FXML
    /**
     * Mostra le medie delle valutazioni per ciascun libro disponibile.
     */
    private void showValutazioniGlobali() {
        VBox vbox = creaVBoxStandard("Media Valutazioni per Libro");
        TextArea area = new TextArea();
        area.setEditable(false);

        repositoryLibri.caricaValutazioni();
        List<Valutazione> lista = repositoryLibri.getValutazioni();

        if (lista.isEmpty()) {
            area.setText("Nessuna valutazione disponibile.");
        } else {
            Map<String, List<Valutazione>> valutazioniPerLibro = lista.stream()
                .collect(Collectors.groupingBy(Valutazione::getTitoloLibro));

            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, List<Valutazione>> entry : valutazioniPerLibro.entrySet()) {
                String titolo = entry.getKey();
                List<Valutazione> valutazioni = entry.getValue();
                int count = valutazioni.size();

                // Medie per categoria
                double mediaStile = valutazioni.stream().mapToInt(Valutazione::getStile).average().orElse(0);
                double mediaContenuto = valutazioni.stream().mapToInt(Valutazione::getContenuto).average().orElse(0);
                double mediaGradevolezza = valutazioni.stream().mapToInt(Valutazione::getGradevolezza).average().orElse(0);
                double mediaOriginalita = valutazioni.stream().mapToInt(Valutazione::getOriginalita).average().orElse(0);
                double mediaEdizione = valutazioni.stream().mapToInt(Valutazione::getEdizione).average().orElse(0);
                double mediaFinale = valutazioni.stream().mapToInt(Valutazione::getVotoFinale).average().orElse(0);

                // Calcolo voto complessivo medio (media delle 6 medie)
                double votoComplessivo = (mediaStile + mediaContenuto + mediaGradevolezza +
                                          mediaOriginalita + mediaEdizione + mediaFinale) / 6.0;

                sb.append("📘 ").append(titolo).append(" (").append(count).append(" valutazioni)\n")
                  .append(" - Stile: ").append(String.format("%.2f", mediaStile)).append("\n")
                  .append(" - Contenuto: ").append(String.format("%.2f", mediaContenuto)).append("\n")
                  .append(" - Gradevolezza: ").append(String.format("%.2f", mediaGradevolezza)).append("\n")
                  .append(" - Originalità: ").append(String.format("%.2f", mediaOriginalita)).append("\n")
                  .append(" - Edizione: ").append(String.format("%.2f", mediaEdizione)).append("\n")
                  .append(" - Voto Finale (dato): ").append(String.format("%.2f", mediaFinale)).append("\n")
                  .append(" ⭐ Voto Complessivo: ").append(String.format("%.2f", votoComplessivo)).append("\n\n");
            }

            area.setText(sb.toString());
        }

        vbox.getChildren().add(area);
        setContenuto(vbox);
    }




    private String chiediTitoloDaLista(Set<String> titoli) {
        ChoiceDialog<String> dialog = new ChoiceDialog<>(titoli.iterator().next(), titoli);
        dialog.setTitle("Selezione libro");
        dialog.setHeaderText("Sono stati trovati più libri:");
        dialog.setContentText("Scegli il titolo corretto:");

        Optional<String> result = dialog.showAndWait();
        return result.orElse(null);
    }

    @FXML
    /**
     * Visualizza il modulo per suggerire un libro in base a un libro letto.
     */
    private void showSuggerimento() {
        VBox vbox = creaVBoxStandard("Suggerisci un Libro");
        TextField campoLetto = creaCampo("Libro letto (titolo)");
        TextField campoSuggerito = creaCampo("Suggerisci (titolo)");
        Button invia = new Button("Invia suggerimento");

        invia.setOnAction(e -> {
            boolean ok = GestioneLibreria.inserisciSuggerimentoLibro(
                utente.getUserId(), campoLetto.getText().trim(), campoSuggerito.getText().trim());
            if (ok) alert("Successo", "Suggerimento inserito.");
            else alert("Errore", "Errore nell'inserimento.");
        });

        vbox.getChildren().addAll(campoLetto, campoSuggerito, invia);
        setContenuto(vbox);
    }
    @FXML
    /**
     * Mostra tutti i suggerimenti inseriti dagli utenti.
     */
    private void showVisualizzaSuggerimenti() {
        VBox vbox = creaVBoxStandard("Suggerimenti della Community");
        TextArea area = new TextArea();
        area.setEditable(false);

        List<SuggerimentoLibro> suggerimenti = GestioneLibreria.caricaSuggerimenti();
        StringBuilder sb = new StringBuilder();

        for (SuggerimentoLibro s : suggerimenti) {
            sb.append(s.getUtenteId()) // qui è lo username
              .append(" consiglia: ")
              .append(s.getTitoloLibroSuggerito())
              .append(" a chi ha letto: ")
              .append(s.getTitoloLibroOriginale())
              .append("\n");
        }

        if (sb.length() == 0) sb.append("Nessun suggerimento disponibile.");

        area.setText(sb.toString());
        vbox.getChildren().add(area);
        setContenuto(vbox);
    }
    @FXML
    /**
     * Mostra i suggerimenti basati su un determinato libro letto.
     */
    private void showSuggerimentiPerLibro() {
        VBox vbox = creaVBoxStandard("Cerca Suggerimenti per Libro Letto");
        
        TextField campoRicerca = creaCampo("Inserisci titolo del libro letto");
        Button cerca = new Button("Cerca suggerimenti");
        TextArea areaRisultati = new TextArea();
        areaRisultati.setEditable(false);

        cerca.setOnAction(e -> {
            String titoloLetto = campoRicerca.getText().trim();
            if (titoloLetto.isEmpty()) {
                alert("Errore", "Inserisci un titolo per cercare.");
                return;
            }

            List<SuggerimentoLibro> risultati = GestioneLibreria.cercaSuggerimentiPerLibroLetto(titoloLetto);
            StringBuilder sb = new StringBuilder();

            for (SuggerimentoLibro s : risultati) {
                sb.append(s.getUtenteId())
                  .append(" consiglia: ")
                  .append(s.getTitoloLibroSuggerito())
                  .append(" a chi ha letto: ")
                  .append(s.getTitoloLibroOriginale())
                  .append("\n");
            }

            if (sb.length() == 0) sb.append("Nessun suggerimento trovato per questo libro.");
            areaRisultati.setText(sb.toString());
        });

        vbox.getChildren().addAll(campoRicerca, cerca, areaRisultati);
        setContenuto(vbox);
    }
   
    @FXML
    /**
     * Effettua il logout dell'utente e torna alla schermata principale.
     */
    public void handleLogout() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/main.fxml")); // 
            Parent root = loader.load();

            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Benvenuto");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            alert("Errore", "Impossibile tornare alla schermata iniziale.");
        }
    }





}