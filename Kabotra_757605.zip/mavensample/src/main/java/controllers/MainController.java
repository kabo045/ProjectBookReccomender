/*Grampa, Marco, 758701, Varese, (Systen architect)
Kabotra, Rahul, 757605, Varese,  (Project manager)
Morena, Matteo, 756150, Varese, (Document & quality manager)
Colombo, Gianluca, 757634, Varese,  (Design manager)*/
package controllers;

import Base.*;
import Networking.Client;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Controller principale della schermata iniziale dell'applicazione.
 * <p>
 * Gestisce le funzionalità pubbliche accessibili senza autenticazione,
 * tra cui:
 * <ul>
 *     <li>Login e registrazione</li>
 *     <li>Ricerca libri per titolo, autore e anno</li>
 *     <li>Visualizzazione delle valutazioni e dei suggerimenti</li>
 *     <li>Calcolo delle medie delle valutazioni</li>
 *     <li>Terminazione dell'applicazione</li>
 * </ul>
 * Inoltre gestisce la transizione alla schermata utente dopo un login riuscito.
 * </p>
 */
public class MainController {

    // Variabili di interfaccia (iniettate da FXML)
    @FXML private Button btnLogin;
    @FXML private Button btnRegistrazione;
    @FXML private Button btnRicercaTitolo;
    @FXML private Button btnRicercaAutore;
    @FXML private Button btnRicercaAutoreAnno;
    @FXML private Button btnEsci;

    @FXML private TextField inputRicerca;
    @FXML private TextField inputAnno;
    @FXML private TextArea areaRisultati;
    @FXML private Button btnMediaGlobale;
    @FXML private Button btnVisualizzaValutazioni;
    @FXML private Button btnVisualizzaSuggerimenti;

    private Client client;
    private RepositoryLibri repository;

    /**
     * Inizializza il repository se fornito esternamente.
     *
     * @param repository oggetto {@link RepositoryLibri} da utilizzare
     */
    public void setRepository(RepositoryLibri repository) {
        this.repository = repository;
        this.repository.caricaLibri();
    }

    /**
     * Inizializza il controller. Crea un client socket, configura i pulsanti
     * e assegna le azioni da eseguire.
     */
    @FXML
    public void initialize() {
        try {
            this.client = new Client();
            System.out.println("Client socket connesso.");
        } catch (IOException e) {
            showAlert("Errore", "Impossibile connettersi al server.");
            btnLogin.setDisable(true);
            btnRegistrazione.setDisable(true);
        }

        // Se non già assegnato, inizializza il repository locale dei libri
        if (this.repository == null) {
            this.repository = new RepositoryLibri();
            this.repository.caricaLibri();
        }

        // Assegnazione azioni ai pulsanti
        btnLogin.setOnAction(e -> apriFinestraLogin());
        btnRegistrazione.setOnAction(e -> apriFinestraRegistrazione());
        btnRicercaTitolo.setOnAction(e -> ricercaTitolo(inputRicerca.getText()));
        btnRicercaAutore.setOnAction(e -> ricercaAutore(inputRicerca.getText()));
        btnRicercaAutoreAnno.setOnAction(e -> {
            if (inputAnno.getText().trim().isEmpty()) {
                areaRisultati.setText("Inserisci un anno.");
                return;
            }
            try {
                int anno = Integer.parseInt(inputAnno.getText().trim());
                ricercaAutoreAnno(inputRicerca.getText(), anno);
            } catch (NumberFormatException ex) {
                areaRisultati.setText("Inserisci un anno valido.");
            }
        });

        // Chiusura dell'applicazione
        btnEsci.setOnAction(e -> {
            if (client != null) client.chiudi();
            Platform.exit();
        });

        // Azioni pubbliche
        btnMediaGlobale.setOnAction(e -> mostraMediaGlobale());
        btnVisualizzaValutazioni.setOnAction(e -> mostraValutazioniGlobali());
        btnVisualizzaSuggerimenti.setOnAction(e -> mostraSuggerimentiCommunity());

        areaRisultati.clear();
    }

    /**
     * Apre la finestra di login in modalità modale.
     * Dopo il login, carica la schermata principale dell’utente.
     */
    private void apriFinestraLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/Login.fxml"));
            Parent root = loader.load();

            LoginController controller = loader.getController();
            controller.setClient(client);

            // Mostra la finestra in modo modale
            Stage loginStage = new Stage();
            loginStage.setTitle("Login");
            loginStage.setScene(new Scene(root));
            loginStage.initModality(Modality.APPLICATION_MODAL);
            loginStage.showAndWait();

            // Se l’utente è autenticato, passa alla Home
            Utenti utente = controller.getUtente();
            if (utente != null) {
                FXMLLoader userLoader = new FXMLLoader(getClass().getResource("/views/Home.fxml"));
                Parent userRoot = userLoader.load();

                HomeController homeController = userLoader.getController();
                homeController.inizializzaUtente(utente);
                homeController.setClient(client);
                homeController.setRepository(new RepositoryLibri());

                Stage stagePrincipale = (Stage) btnLogin.getScene().getWindow();
                stagePrincipale.setScene(new Scene(userRoot, 900, 600));
                stagePrincipale.setTitle("Area Utente - Benvenuto " + utente.getUserId());
            } else {
                showAlert("Login fallito", "Credenziali errate.");
            }

        } catch (IOException ex) {
            ex.printStackTrace();
            showAlert("Errore", "Errore durante il login: " + ex.getMessage());
        }
    }

    /**
     * Apre la finestra di registrazione in modalità modale.
     */
    private void apriFinestraRegistrazione() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/registrazione.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Registrazione");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();
        } catch (IOException ex) {
            ex.printStackTrace();
            showAlert("Errore", "Impossibile aprire la finestra di registrazione.");
        }
    }

    /**
     * Esegue una ricerca per titolo e visualizza i risultati nell'area di testo.
     *
     * @param titolo il titolo da cercare
     */
    public void ricercaTitolo(String titolo) {
        try {
            Messaggio richiesta = new Messaggio("ricerca_titolo", titolo);
            Messaggio risposta = client.inviaRichiesta(richiesta);
            Object contenuto = risposta.getContenuto();

            areaRisultati.clear();
            if (contenuto instanceof List<?> risultati) {
                areaRisultati.setText(risultati.isEmpty() ?
                    "Nessun libro trovato con quel titolo." :
                    formatLibri(risultati));
            } else {
                areaRisultati.setText("Risposta inattesa dal server.");
            }
        } catch (Exception e) {
            areaRisultati.setText("Errore durante la ricerca per titolo: " + e.getMessage());
        }
    }

    /**
     * Esegue una ricerca per autore.
     *
     * @param autore nome dell’autore
     */
    public void ricercaAutore(String autore) {
        try {
            Messaggio richiesta = new Messaggio("ricerca_autore", autore);
            Messaggio risposta = client.inviaRichiesta(richiesta);
            Object contenuto = risposta.getContenuto();

            areaRisultati.clear();
            if (contenuto instanceof List<?> risultati) {
                areaRisultati.setText(risultati.isEmpty() ?
                    "🔍 Nessun libro trovato per quell'autore." :
                    formatLibri(risultati));
            } else {
                areaRisultati.setText("Risposta inattesa dal server.");
            }
        } catch (Exception e) {
            areaRisultati.setText("Errore durante la ricerca per autore: " + e.getMessage());
        }
    }

    /**
     * Esegue una ricerca per autore e anno.
     *
     * @param autore nome dell’autore
     * @param anno   anno di pubblicazione
     */
    public void ricercaAutoreAnno(String autore, int anno) {
        try {
            Object[] dati = new Object[]{autore, anno};
            Messaggio richiesta = new Messaggio("ricerca_autore_anno", dati);
            Messaggio risposta = client.inviaRichiesta(richiesta);
            Object contenuto = risposta.getContenuto();

            areaRisultati.clear();
            if (contenuto instanceof List<?> risultati) {
                areaRisultati.setText(risultati.isEmpty() ?
                    "Nessun libro trovato per quell'autore e anno." :
                    formatLibri(risultati));
            } else {
                areaRisultati.setText("Risposta inattesa dal server.");
            }
        } catch (Exception e) {
            areaRisultati.setText("Errore durante la ricerca per autore e anno: " + e.getMessage());
        }
    }

    /**
     * Converte una lista di libri in una stringa ben formattata per la visualizzazione.
     */
    private String formatLibri(List<?> lista) {
        StringBuilder sb = new StringBuilder();
        for (Object o : lista) {
            if (o instanceof Libro libro) {
                sb.append("📘 Titolo: ").append(libro.getTitolo()).append("\n")
                  .append("✍️ Autore: ").append(libro.getAutori()).append("\n")
                  .append("📅 Anno: ").append(libro.getAnnoPubblicazione()).append("\n")
                  .append("🏷️ Categoria: ").append(libro.getCategoria() != null ? libro.getCategoria() : "N/A").append("\n")
                  .append("🏢 Editore: ").append(libro.getEditore() != null ? libro.getEditore() : "N/A").append("\n")
                  .append("──────────────────────────────\n");
            } else {
                sb.append(o.toString()).append("\n"); // fallback
            }
        }
        return sb.toString();
    }

    /**
     * Mostra la media delle valutazioni finali e complessive per ogni libro.
     */
    private void mostraMediaGlobale() {
        if (repository == null) {
            areaRisultati.setText("Errore interno: repository non inizializzato.");
            return;
        }

        repository.caricaValutazioni();
        List<Valutazione> lista = repository.getValutazioni();

        if (lista.isEmpty()) {
            areaRisultati.setText("Nessuna valutazione disponibile.");
            return;
        }

        Map<String, List<Valutazione>> perLibro = lista.stream()
                .collect(Collectors.groupingBy(Valutazione::getTitoloLibro));

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, List<Valutazione>> entry : perLibro.entrySet()) {
            String titolo = entry.getKey();
            List<Valutazione> valutazioni = entry.getValue();

            double mediaFinale = valutazioni.stream().mapToInt(Valutazione::getVotoFinale).average().orElse(0);
            double mediaTotale = (
                valutazioni.stream().mapToInt(Valutazione::getStile).average().orElse(0) +
                valutazioni.stream().mapToInt(Valutazione::getContenuto).average().orElse(0) +
                valutazioni.stream().mapToInt(Valutazione::getGradevolezza).average().orElse(0) +
                valutazioni.stream().mapToInt(Valutazione::getOriginalita).average().orElse(0) +
                valutazioni.stream().mapToInt(Valutazione::getEdizione).average().orElse(0) +
                mediaFinale
            ) / 6.0;

            sb.append("📘 ").append(titolo).append("\n")
              .append(" - Media finale: ").append(String.format("%.2f", mediaFinale)).append("\n")
              .append(" - Voto complessivo: ").append(String.format("%.2f", mediaTotale)).append("\n\n");
        }

        areaRisultati.setText(sb.toString());
    }

    /**
     * Mostra tutte le valutazioni globali presenti nel sistema.
     */
    private void mostraValutazioniGlobali() {
        if (repository == null) {
            areaRisultati.setText("Errore interno: repository non inizializzato.");
            return;
        }

        repository.caricaValutazioni();
        List<Valutazione> lista = repository.getValutazioni();

        if (lista.isEmpty()) {
            areaRisultati.setText("Nessuna valutazione disponibile.");
            return;
        }

        String result = lista.stream()
                .map(v -> String.format(
                    "📘 %s\nStile: %d, Contenuto: %d, Gradevolezza: %d, Originalità: %d, Edizione: %d, Voto Finale: %d\n",
                    v.getTitoloLibro(), v.getStile(), v.getContenuto(), v.getGradevolezza(),
                    v.getOriginalita(), v.getEdizione(), v.getVotoFinale()
                ))
                .collect(Collectors.joining("\n"));

        areaRisultati.setText(result);
    }

    /**
     * Mostra i suggerimenti forniti dagli utenti per i libri letti.
     */
    private void mostraSuggerimentiCommunity() {
        List<SuggerimentoLibro> suggerimenti = GestioneLibreria.caricaSuggerimenti();

        if (suggerimenti.isEmpty()) {
            areaRisultati.setText("Nessun suggerimento disponibile.");
            return;
        }

        String testo = suggerimenti.stream()
                .map(s -> s.getUtenteId() + " consiglia: " + s.getTitoloLibroSuggerito() +
                        " a chi ha letto: " + s.getTitoloLibroOriginale())
                .collect(Collectors.joining("\n"));

        areaRisultati.setText(testo);
    }

    /**
     * Mostra un alert informativo con titolo e messaggio specificato.
     */
    private void showAlert(String titolo, String messaggio) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titolo);
        alert.setHeaderText(null);
        alert.setContentText(messaggio);
        alert.showAndWait();
    }
}
