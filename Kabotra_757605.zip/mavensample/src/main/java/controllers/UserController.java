/**
 * Controller per la gestione delle operazioni utente nell'applicazione.
 * Gestisce la creazione di librerie, aggiunta di libri, valutazioni,
 * suggerimenti e ricerche.
 * 
 * Autori:
 * - Grampa, Marco, 758701, Varese (System architect)
 * - Kabotra, Rahul, 757605, Varese (Project manager)
 * - Morena, Matteo, 756150, Varese (Document & quality manager)
 * - Colombo, Gianluca, 757634, Varese (Design manager)
 */
package controllers;

import Base.*;
import Networking.Client;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.List;

public class UserController {

    // Riferimento all'utente corrente
    private Utenti utente;
    
    // Client per la comunicazione con il server
    private Client client;

    // Componenti FXML per la gestione delle librerie
    @FXML private TextField nomeLibreriaField;
    @FXML private TextArea outputLibrerie;

    // Componenti FXML per la gestione dei libri
    @FXML private TextField titoloLibroField;
    @FXML private TextField libreriaTargetField;
    @FXML private TextArea outputLibri;

    // Componenti FXML per le valutazioni
    @FXML private TextField titoloValutazioneField;
    @FXML private TextField votoStile, votoContenuto, votoGradevolezza, votoOriginalita, votoEdizione;
    @FXML private TextArea notaGenerale;

    // Componenti FXML per i suggerimenti
    @FXML private TextField titoloLetto;
    @FXML private TextField titoloSuggerito;
    @FXML private TextArea outputSuggerimenti;

    // Componenti FXML per la ricerca
    @FXML private TextField ricercaTitolo;
    @FXML private TextArea outputRicerca;

    /**
     * Imposta l'utente corrente per il controller.
     * @param utente L'utente da impostare
     */
    public void setUtente(Utenti utente) {
        this.utente = utente;
    }

    /**
     * Imposta il client per la comunicazione con il server.
     * @param client Il client da impostare
     */
    public void setClient(Client client) {
        this.client = client;
    }

    /**
     * Gestisce la creazione di una nuova libreria.
     * Verifica che il nome non sia vuoto e invia la richiesta al server.
     */
    @FXML
    private void creaLibreria() {
        String nome = nomeLibreriaField.getText().trim();
        if (nome.isBlank()) {
            outputLibrerie.setText("Inserisci un nome valido.");
            return;
        }

        Messaggio richiesta = new Messaggio("crea_libreria", new Object[]{nome, utente.getUserId()});
        Messaggio risposta = client.inviaRichiesta(richiesta);

        if ("ok".equals(risposta.getComando())) {
            outputLibrerie.setText("Libreria creata: " + nome);
        } else {
            outputLibrerie.setText("Errore: " + risposta.getContenuto());
        }
    }

    /**
     * Aggiunge un libro a una libreria esistente.
     * Verifica che titolo e nome libreria non siano vuoti.
     */
    @FXML
    private void aggiungiLibroALibreria() {
        String titolo = titoloLibroField.getText().trim();
        String nomeLibreria = libreriaTargetField.getText().trim();

        if (titolo.isEmpty() || nomeLibreria.isEmpty()) {
            outputLibri.setText("Inserisci titolo e nome libreria.");
            return;
        }

        Messaggio richiesta = new Messaggio("aggiungi_libro", new Object[]{utente.getUserId(), nomeLibreria, titolo});
        Messaggio risposta = client.inviaRichiesta(richiesta);

        if ("ok".equals(risposta.getComando())) {
            outputLibri.setText("Libro aggiunto a " + nomeLibreria);
        } else {
            outputLibri.setText("Errore: " + risposta.getContenuto());
        }
    }

    /**
     * Salva una valutazione per un libro.
     * Verifica che i voti siano numeri validi tra 1 e 5 e calcola la media.
     */
    @FXML
    private void salvaValutazione() {
        try {
            String titolo = titoloValutazioneField.getText().trim();
            int stile = Integer.parseInt(votoStile.getText().trim());
            int contenuto = Integer.parseInt(votoContenuto.getText().trim());
            int gradevolezza = Integer.parseInt(votoGradevolezza.getText().trim());
            int originalita = Integer.parseInt(votoOriginalita.getText().trim());
            int edizione = Integer.parseInt(votoEdizione.getText().trim());
            String nota = notaGenerale.getText().trim();

            if (!isValido(stile) || !isValido(contenuto) || !isValido(gradevolezza)
                    || !isValido(originalita) || !isValido(edizione)) {
                showAlert("Errore", "I voti devono essere tra 1 e 5.");
                return;
            }

            // Calcola la media dei voti
            int votoFinale = (stile + contenuto + gradevolezza + originalita + edizione) / 5;

            Object[] dati = new Object[]{
                utente.getUserId(), titolo,
                stile, contenuto, gradevolezza, originalita, edizione,
                votoFinale, nota
            };

            Messaggio richiesta = new Messaggio("valutazione_libro", dati);
            Messaggio risposta = client.inviaRichiesta(richiesta);

            if ("ok".equals(risposta.getComando())) {
                showAlert("Successo", "Valutazione salvata.");
            } else {
                showAlert("Errore", "Errore: " + risposta.getContenuto());
            }

        } catch (NumberFormatException e) {
            showAlert("Errore", "Inserisci numeri interi nei voti.");
        }
    }

    /**
     * Aggiunge un suggerimento tra due libri.
     * Verifica che entrambi i campi siano compilati.
     */
    @FXML
    private void aggiungiSuggerimento() {
        String letto = titoloLetto.getText().trim();
        String suggerito = titoloSuggerito.getText().trim();
        if (!letto.isEmpty() && !suggerito.isEmpty()) {
            Messaggio richiesta = new Messaggio("aggiungi_suggerimento", new Object[]{utente.getUserId(), letto, suggerito});
            Messaggio risposta = client.inviaRichiesta(richiesta);
            outputSuggerimenti.setText("ok".equals(risposta.getComando()) ? "Suggerimento salvato!" : "Errore: " + risposta.getContenuto());
        } else {
            outputSuggerimenti.setText("Compila entrambi i campi.");
        }
    }

    /**
     * Visualizza tutti i suggerimenti ricevuti dall'utente.
     */
    @FXML
    private void visualizzaSuggerimenti() {
        Messaggio richiesta = new Messaggio("visualizza_suggerimenti", utente.getUserId());
        Messaggio risposta = client.inviaRichiesta(richiesta);

        List<SuggerimentoLibro> suggerimenti = (List<SuggerimentoLibro>) risposta.getContenuto();
        if (suggerimenti == null || suggerimenti.isEmpty()) {
            outputSuggerimenti.setText("Nessun suggerimento.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (SuggerimentoLibro s : suggerimenti) {
                sb.append(s.getUtenteId()).append(" consiglia ")
                  .append(s.getTitoloLibroSuggerito()).append("\n");
            }
            outputSuggerimenti.setText(sb.toString());
        }
    }

    /**
     * Ricerca libri per titolo.
     * Visualizza i risultati nella textarea dedicata.
     */
    @FXML
    private void ricercaPerTitolo() {
        String titolo = ricercaTitolo.getText().trim();
        if (titolo.isBlank()) {
            outputRicerca.setText("Inserisci un titolo.");
            return;
        }

        Messaggio richiesta = new Messaggio("ricerca_titolo", titolo);
        Messaggio risposta = client.inviaRichiesta(richiesta);

        List<Libro> risultati = (List<Libro>) risposta.getContenuto();
        if (risultati == null || risultati.isEmpty()) {
            outputRicerca.setText("Nessun libro trovato.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (Libro libro : risultati) {
                sb.append(libro).append("\n");
            }
            outputRicerca.setText(sb.toString());
        }
    }

    /**
     * Verifica se un voto è nel range valido (1-5).
     * @param voto Il voto da verificare
     * @return true se il voto è valido, false altrimenti
     */
    private boolean isValido(int voto) {
        return voto >= 1 && voto <= 5;
    }

    /**
     * Mostra un alert con titolo e messaggio specificati.
     * @param titolo Il titolo dell'alert
     * @param messaggio Il messaggio da visualizzare
     */
    private void showAlert(String titolo, String messaggio) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titolo);
        alert.setHeaderText(null);
        alert.setContentText(messaggio);
        alert.showAndWait();
    }

    /**
     * Gestisce il logout dell'utente chiudendo l'applicazione.
     */
    @FXML
    private void logout() {
        System.exit(0);
    }
}