/*
 * Grampa, Marco, 758701, Varese, (System architect)
 * Kabotra, Rahul, 757605, Varese, (Project manager)
 * Morena, Matteo, 756150, Varese, (Document & Quality manager)
 * Colombo, Gianluca, 757634, Varese, (Design manager)
 */

package Base;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * La classe {@code Libro} rappresenta un libro con le sue proprietà principali:
 * titolo, autori, anno di pubblicazione, editore e categoria.
 * <p>
 * È serializzabile per consentire il salvataggio e la lettura da file.
 */
public class Libro implements Serializable {

    private static final long serialVersionUID = 1L;

    /** Titolo del libro. */
    private String titolo;

    /** Autore o autori del libro. */
    private String autori;

    /** Anno di pubblicazione del libro. */
    private int annoPubblicazione;

    /** Editore del libro. */
    private String editore;

    /** Categoria o genere del libro. */
    private String categoria;

    /**
     * Costruttore completo.
     *
     * @param titolo             Titolo del libro.
     * @param autori             Autore o autori del libro.
     * @param annoPubblicazione  Anno di pubblicazione.
     * @param editore            Editore del libro.
     * @param categoria          Categoria o genere.
     */
    public Libro(String titolo, String autori, int annoPubblicazione, String editore, String categoria) {
        this.titolo = titolo;
        this.autori = autori;
        this.annoPubblicazione = annoPubblicazione;
        this.editore = editore;
        this.categoria = categoria;
    }

    /**
     * Costruttore che permette di creare un libro direttamente da un {@link ResultSet}.
     *
     * @param rs ResultSet contenente i dati del libro.
     * @throws SQLException Se i dati non sono accessibili o mancano.
     */
    public Libro(ResultSet rs) throws SQLException {
        this.titolo = rs.getString("titolo");
        this.autori = rs.getString("autore");
        this.annoPubblicazione = rs.getInt("anno_pubblicazione");
        this.editore = rs.getString("editore");
        this.categoria = rs.getString("categoria");
    }

    // === Metodi getter ===

    /**
     * Restituisce il titolo del libro.
     * @return Titolo del libro.
     */
    public String getTitolo() {
        return titolo;
    }

    /**
     * Restituisce gli autori del libro.
     * @return Autori del libro.
     */
    public String getAutori() {
        return autori;
    }

    /**
     * Restituisce l'anno di pubblicazione del libro.
     * @return Anno di pubblicazione.
     */
    public int getAnnoPubblicazione() {
        return annoPubblicazione;
    }

    /**
     * Restituisce l'editore del libro.
     * @return Editore.
     */
    public String getEditore() {
        return editore;
    }

    /**
     * Restituisce la categoria del libro.
     * @return Categoria.
     */
    public String getCategoria() {
        return categoria;
    }

    // === Metodi setter ===

    /**
     * Imposta l'anno di pubblicazione del libro.
     * @param annoPubblicazione Nuovo anno.
     */
    public void setAnnoPubblicazione(int annoPubblicazione) {
        this.annoPubblicazione = annoPubblicazione;
    }

    // === Metodo di utilità ===

    /**
     * Restituisce una rappresentazione testuale del libro.
     * Utile per la stampa su console o file di log.
     *
     * @return Stringa descrittiva del libro.
     */
    @Override
    public String toString() {
        return String.format("%s; %s; %d; %s; %s",
                titolo,
                autori,
                annoPubblicazione,
                editore != null ? editore : "N/A",
                categoria != null ? categoria : "N/A");
    }

    /**
     * Converte una riga in formato CSV in un oggetto {@code Libro}.
     * Il CSV può contenere campi delimitati da virgole e virgolette.
     *
     * @param line Riga del file da convertire.
     * @return Oggetto {@code Libro} creato dalla riga.
     * @throws IllegalArgumentException Se la riga ha un formato non valido.
     */
    public static Libro stringToOggetto(String line) {
        String[] parts = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
        if (parts.length < 5) {
            throw new IllegalArgumentException("Linea di input non valida: " + line);
        }

        String titolo = parts[0].trim().replace("\"", "");
        String autori = parts.length > 1 ? parts[1].replace("By ", "").trim().replace("\"", "") : "Autore sconosciuto";

        int annoPubblicazione = 0;
        String editore = "Editore sconosciuto";
        String categoria = "Non specificata";

        // Estrazione anno di pubblicazione
        if (parts.length > 7 && !parts[7].trim().isEmpty()) {
            try {
                annoPubblicazione = Integer.parseInt(parts[7].trim());
            } catch (NumberFormatException e) {
                System.out.println("Anno non valido per il libro: " + titolo);
            }
        }

        // Estrazione editore
        if (parts.length > 4 && !parts[4].trim().isEmpty()) {
            editore = parts[4].trim().replace("\"", "");
        }

        // Estrazione categoria
        if (parts.length > 3 && !parts[3].trim().isEmpty()) {
            categoria = parts[3].trim().replace("\"", "");
        }

        return new Libro(titolo, autori, annoPubblicazione, editore, categoria);
    }
}
