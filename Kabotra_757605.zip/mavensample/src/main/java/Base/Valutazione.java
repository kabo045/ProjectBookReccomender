/*Grampa, Marco, 758701, Varese, (Systen architect)
Kabotra, Rahul, 757605, Varese,  (Project manager)
Morena, Matteo, 756150, Varese, (Document & quality manager)
Colombo, Gianluca, 757634, Varese,  (Design manager)*/
package Base;

import java.io.Serializable;

/**
 * La classe {@code Valutazione} rappresenta una valutazione dettagliata fatta da un utente
 * su un libro. Ogni valutazione include punteggi numerici e note testuali per diversi criteri.
 * <p>
 * La classe implementa {@link Serializable} per permettere la trasmissione in rete
 * o la persistenza su disco.
 * </p>
 */
public class Valutazione implements Serializable {
    
    private static final long serialVersionUID = 1L;

    /** ID dell'utente che ha effettuato la valutazione */
    private String utenteId;

    /** Titolo del libro valutato */
    private String titoloLibro;

    /** Valutazione sullo stile di scrittura */
    private int stile;

    /** Nota opzionale sullo stile di scrittura */
    private String notaStile;

    /** Valutazione sul contenuto del libro */
    private int contenuto;

    /** Nota opzionale sul contenuto */
    private String notaContenuto;

    /** Valutazione sulla gradevolezza della lettura */
    private int gradevolezza;

    /** Nota opzionale sulla gradevolezza */
    private String notaGradevolezza;

    /** Valutazione sull'originalità dell'opera */
    private int originalita;

    /** Nota opzionale sull'originalità */
    private String notaOriginalita;

    /** Valutazione sull'edizione (impaginazione, stampa, ecc.) */
    private int edizione;

    /** Nota opzionale sull'edizione */
    private String notaEdizione;

    /** Voto finale globale assegnato al libro */
    private int votoFinale;

    /** Nota generale aggiuntiva */
    private String notaGenerale;

    /**
     * Costruttore completo della classe {@code Valutazione}.
     *
     * @param utenteId           ID dell'utente
     * @param titoloLibro        Titolo del libro
     * @param stile              Valutazione dello stile
     * @param notaStile          Nota sullo stile
     * @param contenuto          Valutazione del contenuto
     * @param notaContenuto      Nota sul contenuto
     * @param gradevolezza       Valutazione della gradevolezza
     * @param notaGradevolezza   Nota sulla gradevolezza
     * @param originalita        Valutazione dell'originalità
     * @param notaOriginalita    Nota sull'originalità
     * @param edizione           Valutazione dell'edizione
     * @param notaEdizione       Nota sull'edizione
     * @param votoFinale         Voto finale
     * @param notaGenerale       Nota generale
     */
    public Valutazione(String utenteId, String titoloLibro, int stile, String notaStile,
                       int contenuto, String notaContenuto, int gradevolezza, String notaGradevolezza,
                       int originalita, String notaOriginalita, int edizione, String notaEdizione,
                       int votoFinale, String notaGenerale) {
        this.utenteId = utenteId;
        this.titoloLibro = titoloLibro;
        this.stile = stile;
        this.notaStile = notaStile;
        this.contenuto = contenuto;
        this.notaContenuto = notaContenuto;
        this.gradevolezza = gradevolezza;
        this.notaGradevolezza = notaGradevolezza;
        this.originalita = originalita;
        this.notaOriginalita = notaOriginalita;
        this.edizione = edizione;
        this.notaEdizione = notaEdizione;
        this.votoFinale = votoFinale;
        this.notaGenerale = notaGenerale;
    }

    // Metodi getter

    public String getUtenteId() {
        return utenteId;
    }

    public String getTitoloLibro() {
        return titoloLibro;
    }

    public int getStile() {
        return stile;
    }

    public String getNotaStile() {
        return notaStile;
    }

    public int getContenuto() {
        return contenuto;
    }

    public String getNotaContenuto() {
        return notaContenuto;
    }

    public int getGradevolezza() {
        return gradevolezza;
    }

    public String getNotaGradevolezza() {
        return notaGradevolezza;
    }

    public int getOriginalita() {
        return originalita;
    }

    public String getNotaOriginalita() {
        return notaOriginalita;
    }

    public int getEdizione() {
        return edizione;
    }

    public String getNotaEdizione() {
        return notaEdizione;
    }

    public int getVotoFinale() {
        return votoFinale;
    }

    public String getNotaGenerale() {
        return notaGenerale;
    }

    // Metodi setter

    public void setUtenteId(String utenteId) {
        this.utenteId = utenteId;
    }

    public void setTitoloLibro(String titoloLibro) {
        this.titoloLibro = titoloLibro;
    }

    public void setStile(int stile) {
        this.stile = stile;
    }

    public void setNotaStile(String notaStile) {
        this.notaStile = notaStile;
    }

    public void setContenuto(int contenuto) {
        this.contenuto = contenuto;
    }

    public void setNotaContenuto(String notaContenuto) {
        this.notaContenuto = notaContenuto;
    }

    public void setGradevolezza(int gradevolezza) {
        this.gradevolezza = gradevolezza;
    }

    public void setNotaGradevolezza(String notaGradevolezza) {
        this.notaGradevolezza = notaGradevolezza;
    }

    public void setOriginalita(int originalita) {
        this.originalita = originalita;
    }

    public void setNotaOriginalita(String notaOriginalita) {
        this.notaOriginalita = notaOriginalita;
    }

    public void setEdizione(int edizione) {
        this.edizione = edizione;
    }

    public void setNotaEdizione(String notaEdizione) {
        this.notaEdizione = notaEdizione;
    }

    public void setVotoFinale(int votoFinale) {
        this.votoFinale = votoFinale;
    }

    public void setNotaGenerale(String notaGenerale) {
        this.notaGenerale = notaGenerale;
    }

    /**
     * Restituisce una rappresentazione testuale dell'oggetto {@code Valutazione}.
     *
     * @return Una stringa con i dettagli della valutazione.
     */
    @Override
    public String toString() {
        return "Valutazione [utenteId=" + utenteId + ", titoloLibro=" + titoloLibro +
               ", stile=" + stile + ", notaStile=" + notaStile +
               ", contenuto=" + contenuto + ", notaContenuto=" + notaContenuto +
               ", gradevolezza=" + gradevolezza + ", notaGradevolezza=" + notaGradevolezza +
               ", originalita=" + originalita + ", notaOriginalita=" + notaOriginalita +
               ", edizione=" + edizione + ", notaEdizione=" + notaEdizione +
               ", votoFinale=" + votoFinale + ", notaGenerale=" + notaGenerale + "]";
    }
}
