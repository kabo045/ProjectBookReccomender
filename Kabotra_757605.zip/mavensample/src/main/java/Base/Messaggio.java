/*Grampa, Marco, 758701, Varese, (Systen architect)
Kabotra, Rahul, 757605, Varese,  (Project manager)
Morena, Matteo, 756150, Varese, (Document & quality manager)
Colombo, Gianluca, 757634, Varese,  (Design manager)*/
package Base;

import java.io.Serializable;

/**
 * La classe {@code Messaggio} rappresenta un oggetto serializzabile utilizzato per la comunicazione
 * tra componenti dell'applicazione. Contiene un comando testuale e un contenuto generico associato.
 *
 * <p>Questa classe è utile per implementare la comunicazione client-server o tra thread
 * all'interno del sistema, permettendo di trasmettere istruzioni e dati in modo strutturato.</p>
 * 
 * @author 
 */
public class Messaggio implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * Il comando da eseguire, rappresentato come stringa.
     */
    private String comando;

    /**
     * Il contenuto associato al comando, può essere qualsiasi oggetto.
     */
    private Object contenuto;

    /**
     * Costruttore della classe {@code Messaggio}.
     *
     * @param comando   Il comando da eseguire.
     * @param contenuto Il contenuto associato al comando.
     */
    public Messaggio(String comando, Object contenuto) {
        this.comando = comando;
        this.contenuto = contenuto;
    }

    /**
     * Restituisce il comando del messaggio.
     *
     * @return Il comando come stringa.
     */
    public String getComando() {
        return comando;
    }

    /**
     * Restituisce il contenuto del messaggio.
     *
     * @return Il contenuto come oggetto {@link Object}.
     */
    public Object getContenuto() {
        return contenuto;
    }

    /**
     * Imposta un nuovo comando per il messaggio.
     *
     * @param comando Il nuovo comando.
     */
    public void setComando(String comando) {
        this.comando = comando;
    }

    /**
     * Imposta un nuovo contenuto per il messaggio.
     *
     * @param contenuto Il nuovo contenuto.
     */
    public void setContenuto(Object contenuto) {
        this.contenuto = contenuto;
    }
}
