/*
 * Grampa, Marco, 758701, Varese, (System architect)
 * Kabotra, Rahul, 757605, Varese, (Project manager)
 * Morena, Matteo, 756150, Varese, (Document & Quality manager)
 * Colombo, Gianluca, 757634, Varese, (Design manager)
 */

package Base;

import java.util.List;
import java.util.ArrayList;

/**
 * Rappresenta una libreria virtuale contenente un insieme di libri associati a un utente (proprietario).
 * Ogni libreria ha un identificativo, un nome, un ID del proprietario e una lista di libri.
 */
public class Libreria {
    /** Identificativo univoco della libreria nel database. */
    private int id;

    /** Nome della libreria. */
    private String nome;

    /** ID del proprietario della libreria (associato a un utente). */
    private int proprietarioId;

    /** Lista dei libri contenuti nella libreria. */
    private List<Libro> libri;

    /**
     * Costruttore base per creare una libreria con nome e ID del proprietario.
     * Inizializza la lista dei libri come vuota.
     *
     * @param nome          Nome della libreria.
     * @param proprietarioId ID del proprietario della libreria.
     */
    public Libreria(String nome, int proprietarioId) {
        this.nome = nome;
        this.proprietarioId = proprietarioId;
        this.libri = new ArrayList<>();
    }

    /**
     * Costruttore completo per creare una libreria con tutti gli attributi specificati.
     *
     * @param id            Identificativo univoco della libreria.
     * @param nome          Nome della libreria.
     * @param proprietarioId ID del proprietario.
     * @param libri         Lista dei libri da associare (può essere null).
     */
    public Libreria(int id, String nome, int proprietarioId, List<Libro> libri) {
        this.id = id;
        this.nome = nome;
        this.proprietarioId = proprietarioId;
        this.libri = libri != null ? libri : new ArrayList<>();
    }

    /**
     * Restituisce l'ID della libreria.
     *
     * @return ID della libreria.
     */
    public int getId() {
        return id;
    }

    /**
     * Imposta l'ID della libreria.
     *
     * @param id Nuovo ID da assegnare.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Restituisce il nome della libreria.
     *
     * @return Nome della libreria.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Imposta il nome della libreria.
     *
     * @param nome Nuovo nome da assegnare.
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Restituisce l'ID del proprietario della libreria.
     *
     * @return ID del proprietario.
     */
    public int getProprietarioId() {
        return proprietarioId;
    }

    /**
     * Imposta l'ID del proprietario della libreria.
     *
     * @param proprietarioId Nuovo ID del proprietario.
     */
    public void setProprietarioId(int proprietarioId) {
        this.proprietarioId = proprietarioId;
    }

    /**
     * Restituisce la lista dei libri contenuti nella libreria.
     *
     * @return Lista di oggetti {@link Libro}.
     */
    public List<Libro> getLibri() {
        return libri;
    }

    /**
     * Imposta la lista dei libri nella libreria.
     *
     * @param libri Nuova lista di libri.
     */
    public void setLibri(List<Libro> libri) {
        this.libri = libri;
    }

    /**
     * Aggiunge un libro alla libreria.
     *
     * @param libro Oggetto {@link Libro} da aggiungere.
     */
    public void aggiungiLibro(Libro libro) {
        this.libri.add(libro);
    }

    /**
     * Restituisce una rappresentazione testuale della libreria.
     *
     * @return Stringa con il nome della libreria e il numero di libri contenuti.
     */
    @Override
    public String toString() {
        return nome + " (" + libri.size() + " libri)";
    }
}
