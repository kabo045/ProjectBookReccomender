/**
 * Grampa, Marco, 758701, Varese, (System architect)
 * Kabotra, Rahul, 757605, Varese, (Project manager)
 * Morena, Matteo, 756150, Varese, (Document & quality manager)
 * Colombo, Gianluca, 757634, Varese, (Design manager)
 */
package Base;

import database.ConnessioneDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Classe che gestisce le operazioni relative a librerie e libri,
 * interagendo con un database tramite JDBC.
 */
public class GestioneLibreria {
    private static final Logger logger = Logger.getLogger(GestioneLibreria.class.getName());

    // ===============================
    //          GESTIONE LIBRERIE
    // ===============================

    /**
     * Registra una nuova libreria nel database se non è già presente.
     *
     * @param libreria Oggetto Libreria da registrare
     */
    public static void registraLibreria(Libreria libreria) {
        if (libreriaEsiste(libreria.getNome(), libreria.getProprietarioId())) {
            logger.warning("Libreria già esistente:" + libreria.getNome());
            return;
        }

        String sql = "INSERT INTO librerie (nome, id_utente) VALUES (?, ?)";
        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, libreria.getNome());
            stmt.setInt(2, libreria.getProprietarioId());
            stmt.executeUpdate();

            logger.info("Libreria registrata con successo: " + libreria.getNome());
        } catch (SQLException e) {
            logger.severe("Errore durante la registrazione della libreria: " + e.getMessage());
        }
    }

    /**
     * Carica tutte le librerie presenti nel database.
     *
     * @return Lista di oggetti Libreria
     */
    public static List<Libreria> caricaLibrerie() {
        List<Libreria> librerie = new ArrayList<>();
        String sql = """
            SELECT l.id AS id_libreria, l.nome AS nome_libreria, u.id AS id_utente
            FROM librerie l
            JOIN utenti u ON l.id_utente = u.id
            """;

        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int idLibreria = rs.getInt("id_libreria");
                String nome = rs.getString("nome_libreria");
                int proprietarioId = rs.getInt("id_utente");
                List<Libro> libri = caricaLibriPerLibreria(conn, idLibreria);
                librerie.add(new Libreria(idLibreria, nome, proprietarioId, libri));
            }

        } catch (SQLException e) {
            logger.severe("Errore caricamento librerie: " + e.getMessage());
        }

        return librerie;
    }

    /**
     * Verifica se una libreria con lo stesso nome e proprietario esiste già.
     *
     * @param nome Nome della libreria
     * @param idUtente ID del proprietario
     * @return true se esiste, false altrimenti
     */
    private static boolean libreriaEsiste(String nome, int idUtente) {
        String sql = "SELECT id FROM librerie WHERE nome = ? AND id_utente = ?";
        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setInt(2, idUtente);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            logger.severe("Errore controllo esistenza libreria: " + e.getMessage());
            return false;
        }
    }

    // ===============================
    //         GESTIONE LIBRI
    // ===============================

    /**
     * Aggiunge un libro a una libreria specifica se non già presente.
     *
     * @param nomeLibreria Nome della libreria
     * @param userId ID dell'utente (come stringa)
     * @param titoloLibro Titolo del libro da aggiungere
     */
    public static void aggiungiLibroALibreria(String nomeLibreria, String userId, String titoloLibro) {
        try (Connection conn = ConnessioneDB.getConnection()) {
            int idUtente = getIdUtente(conn, userId);
            int idLibreria = getIdLibreria(conn, nomeLibreria, idUtente);
            int idLibro = getIdLibro(conn, titoloLibro);

            if (idLibreria == -1 || idLibro == -1) {
                logger.warning("Libreria o libro non trovato.");
                return;
            }

            if (libroGiaPresente(conn, idLibreria, idLibro)) {
                logger.info("Il libro è già presente nella libreria.");
                return;
            }

            String insertRel = "INSERT INTO libri_librerie (id_libreria, id_libro) VALUES (?, ?)";
            try (PreparedStatement insertStmt = conn.prepareStatement(insertRel)) {
                insertStmt.setInt(1, idLibreria);
                insertStmt.setInt(2, idLibro);
                insertStmt.executeUpdate();
            }

            logger.info("Libro aggiunto alla libreria con successo.");
        } catch (SQLException e) {
            logger.severe("Errore aggiunta libro alla libreria: " + e.getMessage());
        }
    }

    /**
     * Elimina una libreria e tutti i riferimenti ai libri associati.
     *
     * @param nomeLibreria Nome della libreria
     * @param userId ID dell'utente
     */
    public static void eliminaLibreria(String nomeLibreria, String userId) {
        try (Connection conn = ConnessioneDB.getConnection()) {
            int idUtente = getIdUtente(conn, userId);
            int idLibreria = getIdLibreria(conn, nomeLibreria, idUtente);

            if (idLibreria == -1) {
                logger.warning("Libreria non trovata per l'utente specificato.");
                return;
            }

            // Elimina prima i riferimenti alla libreria nella tabella di relazione
            String deleteRel = "DELETE FROM libri_librerie WHERE id_libreria = ?";
            try (PreparedStatement stmtRel = conn.prepareStatement(deleteRel)) {
                stmtRel.setInt(1, idLibreria);
                stmtRel.executeUpdate();
            }

            // Poi elimina la libreria vera e propria
            String deleteLibreria = "DELETE FROM librerie WHERE id = ?";
            try (PreparedStatement stmtLib = conn.prepareStatement(deleteLibreria)) {
                stmtLib.setInt(1, idLibreria);
                stmtLib.executeUpdate();
            }

            logger.info("Libreria eliminata con successo.");
        } catch (SQLException e) {
            logger.severe("Errore durante l'eliminazione della libreria: " + e.getMessage());
        }
    }

    /**
     * Rimuove un libro da una libreria.
     *
     * @param nomeLibreria Nome della libreria
     * @param userId ID dell'utente
     * @param titoloLibro Titolo del libro da rimuovere
     */
    public static void eliminaLibroDaLibreria(String nomeLibreria, String userId, String titoloLibro) {
        try (Connection conn = ConnessioneDB.getConnection()) {
            int idUtente = getIdUtente(conn, userId);
            int idLibreria = getIdLibreria(conn, nomeLibreria, idUtente);
            int idLibro = getIdLibro(conn, titoloLibro);

            if (idLibreria == -1 || idLibro == -1) {
                logger.warning("Libreria o libro non trovato.");
                return;
            }

            String deleteQuery = "DELETE FROM libri_librerie WHERE id_libreria = ? AND id_libro = ?";
            try (PreparedStatement stmt = conn.prepareStatement(deleteQuery)) {
                stmt.setInt(1, idLibreria);
                stmt.setInt(2, idLibro);
                int affectedRows = stmt.executeUpdate();

                if (affectedRows > 0) {
                    logger.info("Libro rimosso con successo dalla libreria.");
                } else {
                    logger.info("Il libro non è presente nella libreria.");
                }
            }

        } catch (SQLException e) {
            logger.severe("Errore durante la rimozione del libro dalla libreria: " + e.getMessage());
        }
    }

    /**
     * Carica i libri presenti in una libreria specifica.
     *
     * @param conn Connessione aperta al database
     * @param idLibreria ID della libreria
     * @return Lista di oggetti Libro
     */
    public static List<Libro> caricaLibriPerLibreria(Connection conn, int idLibreria) {
        List<Libro> libri = new ArrayList<>();
        String sql = """
            SELECT lb.id, lb.titolo, lb.autore, lb.anno_pubblicazione, lb.editore, lb.categoria
            FROM libri lb
            JOIN libri_librerie ll ON lb.id = ll.id_libro
            WHERE ll.id_libreria = ?
        """;

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idLibreria);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    libri.add(new Libro(
                        rs.getString("titolo"),
                        rs.getString("autore"),
                        rs.getInt("anno_pubblicazione"),
                        rs.getString("editore"),
                        rs.getString("categoria")
                    ));
                }
            }

        } catch (SQLException e) {
            System.err.println("Errore durante il caricamento libri per libreria ID " + idLibreria + ": " + e.getMessage());
        }

        return libri;
    }

    /**
     * Esegue una ricerca fuzzy sul titolo dei libri.
     *
     * @param conn Connessione al database
     * @param filtro Filtro di ricerca (parziale)
     * @return Mappa titolo-libro → ID
     * @throws SQLException in caso di errore SQL
     */
    public static Map<String, Integer> cercaLibriFuzzy(Connection conn, String filtro) throws SQLException {
        String sql = "SELECT id, titolo FROM libri WHERE LOWER(titolo) LIKE LOWER(?)";
        Map<String, Integer> risultati = new LinkedHashMap<>();

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + filtro.trim() + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    risultati.put(rs.getString("titolo"), rs.getInt("id"));
                }
            }
        }

        return risultati;
    }

    /**
     * Visualizza in formato testuale le informazioni dettagliate di un libro.
     *
     * @param titolo Titolo del libro
     * @return Stringa formattata con dettagli e valutazioni
     */
    public static String visualizzaLibroComeTesto(String titolo) {
        StringBuilder output = new StringBuilder();

        if (titolo == null || titolo.isBlank()) {
            return "Titolo non valido.";
        }

        try (Connection conn = ConnessioneDB.getConnection()) {
            String libroSql = "SELECT * FROM libri WHERE LOWER(titolo) LIKE LOWER(?)";
            PreparedStatement libroStmt = conn.prepareStatement(libroSql);
            libroStmt.setString(1, "%" + titolo.trim().toLowerCase() + "%");
            ResultSet libroRs = libroStmt.executeQuery();

            if (!libroRs.next()) {
                return "Libro non trovato.";
            }

            output.append("\n--- Dettagli del Libro ---\n")
                .append("Titolo: ").append(libroRs.getString("titolo")).append("\n")
                .append("Autore: ").append(libroRs.getString("autore")).append("\n")
                .append("Anno: ").append(libroRs.getInt("anno_pubblicazione")).append("\n")
                .append("Editore: ").append(libroRs.getString("editore")).append("\n")
                .append("Categoria: ").append(libroRs.getString("categoria")).append("\n");

            int idLibro = libroRs.getInt("id");

            // Valutazioni medie
            String mediaSql = """
                SELECT AVG(stile) AS media_stile,
                       AVG(contenuto) AS media_contenuto,
                       AVG(gradevolezza) AS media_gradevolezza,
                       AVG(originalita) AS media_originalita,
                       AVG(edizione) AS media_edizione,
                       AVG(voto_finale) AS media_finale
                FROM valutazioni WHERE id_libro = ?
            """;

            PreparedStatement mediaStmt = conn.prepareStatement(mediaSql);
            mediaStmt.setInt(1, idLibro);
            ResultSet mediaRs = mediaStmt.executeQuery();

            if (mediaRs.next() && mediaRs.getDouble("media_finale") > 0) {
                output.append("\n--- Valutazioni Medie ---\n")
                      .append(String.format("Stile: %.2f%n", mediaRs.getDouble("media_stile")))
                      .append(String.format("Contenuto: %.2f%n", mediaRs.getDouble("media_contenuto")))
                      .append(String.format("Gradevolezza: %.2f%n", mediaRs.getDouble("media_gradevolezza")))
                      .append(String.format("Originalità: %.2f%n", mediaRs.getDouble("media_originalita")))
                      .append(String.format("Edizione: %.2f%n", mediaRs.getDouble("media_edizione")))
                      .append(String.format("Voto Finale: %.2f%n", mediaRs.getDouble("media_finale")));
            } else {
                output.append("\nNessuna valutazione media disponibile.\n");
            }

            // Note testuali
            String noteSql = """
                SELECT u.username,
                       v.nota_stile, v.nota_contenuto, v.nota_gradevolezza,
                       v.nota_originalita, v.nota_edizione, v.nota_generale
                FROM valutazioni v
                JOIN utenti u ON v.id_utente = u.id
                WHERE v.id_libro = ?
            """;

            PreparedStatement noteStmt = conn.prepareStatement(noteSql);
            noteStmt.setInt(1, idLibro);
            ResultSet noteRs = noteStmt.executeQuery();

            int count = 1;
            boolean almenoUnaNota = false;

            while (noteRs.next()) {
                StringBuilder sb = new StringBuilder();
                sb.append("\nValutazione #").append(count++).append(" (utente: ")
                  .append(noteRs.getString("username")).append(")\n");

                appendNotaIfNotBlank(sb, "Stile", noteRs.getString("nota_stile"));
                appendNotaIfNotBlank(sb, "Contenuto", noteRs.getString("nota_contenuto"));
                appendNotaIfNotBlank(sb, "Gradevolezza", noteRs.getString("nota_gradevolezza"));
                appendNotaIfNotBlank(sb, "Originalità", noteRs.getString("nota_originalita"));
                appendNotaIfNotBlank(sb, "Edizione", noteRs.getString("nota_edizione"));
                appendNotaIfNotBlank(sb, "Nota Generale", noteRs.getString("nota_generale"));

                output.append(sb);
                almenoUnaNota = true;
            }

            if (!almenoUnaNota) {
                output.append("\nQuesto libro non ha ancora ricevuto note dagli utenti.\n");
            }

        } catch (Exception e) {
            return "Errore: " + e.getMessage();
        }

        return output.toString();
    }

    /**
     * Aggiunge una riga al report se la nota non è vuota o nulla.
     *
     * @param sb StringBuilder a cui aggiungere la riga
     * @param etichetta Nome del campo
     * @param nota Nota da aggiungere
     */
    private static void appendNotaIfNotBlank(StringBuilder sb, String etichetta, String nota) {
        if (nota != null && !nota.isBlank()) {
            sb.append("• ").append(etichetta).append(": ").append(nota).append("\n");
        }
    }

    // NOTA: i metodi getIdUtente, getIdLibreria, getIdLibro, libroGiaPresente non sono forniti.
    // Si assume siano presenti altrove nel progetto.


	/**
	 * Inserisce una valutazione per un libro da parte di un utente.
	 *
	 * @param userId ID dell'utente (come stringa, es. username).
	 * @param idLibro ID del libro da valutare.
	 * @param stile Valutazione dello stile del libro.
	 * @param notaStile Nota testuale relativa allo stile.
	 * @param contenuto Valutazione del contenuto.
	 * @param notaContenuto Nota testuale relativa al contenuto.
	 * @param gradevolezza Valutazione della gradevolezza.
	 * @param notaGradevolezza Nota testuale sulla gradevolezza.
	 * @param originalita Valutazione dell’originalità.
	 * @param notaOriginalita Nota testuale sull’originalità.
	 * @param edizione Valutazione dell’edizione.
	 * @param notaEdizione Nota testuale sull’edizione.
	 * @param votoFinale Voto finale globale.
	 * @param notaGenerale Nota finale generale.
	 * @return true se la valutazione è stata inserita correttamente, false altrimenti.
	 */
    public static boolean inserisciValutazioneLibro(String userId, int idLibro, 
            int stile, String notaStile,
            int contenuto, String notaContenuto,
            int gradevolezza, String notaGradevolezza,
            int originalita, String notaOriginalita,
            int edizione, String notaEdizione,
            int votoFinale, String notaGenerale) {

        String sql = "INSERT INTO valutazioni (id_libro, id_utente, stile, nota_stile, contenuto, nota_contenuto, " +
                     "gradevolezza, nota_gradevolezza, originalita, nota_originalita, edizione, nota_edizione, " +
                     "voto_finale, nota_generale) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConnessioneDB.getConnection()) {
            int idUtente = getIdUtente(conn, userId);
            if (idUtente == -1) {
                logger.warning("Utente non trovato: " + userId);
                return false;
            }

            if (!libroEsistePerId(conn, idLibro)) {
                logger.warning("Libro con ID non trovato: " + idLibro);
                return false;
            }

            if (valutazioneEsiste(conn, idUtente, idLibro)) {
                logger.info("Valutazione già esistente per questo utente e libro.");
                return false;
            }

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idLibro);
                stmt.setInt(2, idUtente);
                stmt.setInt(3, stile);
                stmt.setString(4, notaStile);
                stmt.setInt(5, contenuto);
                stmt.setString(6, notaContenuto);
                stmt.setInt(7, gradevolezza);
                stmt.setString(8, notaGradevolezza);
                stmt.setInt(9, originalita);
                stmt.setString(10, notaOriginalita);
                stmt.setInt(11, edizione);
                stmt.setString(12, notaEdizione);
                stmt.setInt(13, votoFinale);
                stmt.setString(14, notaGenerale);
                stmt.executeUpdate();
            }

            logger.info("Valutazione completa inserita per libro ID: " + idLibro);
            return true;

        } catch (SQLException e) {
            logger.severe("Errore durante inserimento valutazione: " + e.getMessage());
            return false;
        }
    }
    /**
     * Verifica se un libro esiste nel database dato il suo ID.
     *
     * @param conn Connessione al database.
     * @param idLibro ID del libro.
     * @return true se il libro esiste, false altrimenti.
     * @throws SQLException se si verifica un errore SQL.
     */
    private static boolean libroEsistePerId(Connection conn, int idLibro) throws SQLException {
        String sql = "SELECT 1 FROM libri WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idLibro);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }
    /**
     * Verifica se esiste una valutazione per un determinato utente e libro.
     *
     * @param conn Connessione al database.
     * @param idUtente ID dell'utente.
     * @param idLibro ID del libro.
     * @return true se esiste già una valutazione, false altrimenti.
     * @throws SQLException se si verifica un errore SQL.
     */
    private static boolean valutazioneEsiste(Connection conn, int idUtente, int idLibro) throws SQLException {
        String sql = "SELECT 1 FROM valutazioni WHERE id_libro = ? AND id_utente = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idLibro);
            stmt.setInt(2, idUtente);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }


    // SUGGERIMENTI
    /**
     * Verifica se l'utente ha già suggerito lo stesso libro almeno 3 volte.
     *
     * @param conn Connessione al database.
     * @param idUtente ID dell'utente.
     * @param titoloLetto Titolo del libro letto.
     * @return true se l'utente ha superato il limite, false altrimenti.
     * @throws SQLException se si verifica un errore SQL.
     */
    private static boolean haTroppiSuggerimenti(Connection conn, int idUtente, String titoloLetto) throws SQLException {
        String sql = "SELECT COUNT(*) FROM suggerimenti WHERE id_utente = ? AND LOWER(letto) = LOWER(?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUtente);
            stmt.setString(2, titoloLetto);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) >= 3;
            }
        }
        return true; // fallback per sicurezza
    }
    /**
     * Inserisce un suggerimento di lettura per un utente.
     *
     * @param username Username dell’utente.
     * @param titoloLetto Titolo del libro che l’utente ha letto.
     * @param titoloSuggerito Titolo del libro che si vuole suggerire.
     * @return true se il suggerimento è stato inserito con successo, false altrimenti.
     */
    public static boolean inserisciSuggerimentoLibro(String username, String titoloLetto, String titoloSuggerito) {
        String sql = "INSERT INTO suggerimenti (id_utente, letto, suggerito) VALUES (?, ?, ?)";

        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            int idUtente = getIdUtente(conn, username);
            if (idUtente == -1) {
                logger.warning("Utente non trovato: " + username);
                return false;
            }

            // Verifica che i libri esistano nel DB
            if (!libroEsiste(conn, titoloLetto)) {
                logger.warning("Libro 'letto' non esistente nel database: " + titoloLetto);
                return false;
            }
            if (!libroEsiste(conn, titoloSuggerito)) {
                logger.warning("Libro 'suggerito' non esistente nel database: " + titoloSuggerito);
                return false;
            }

            // Limite suggerimenti per quel libro
            if (haTroppiSuggerimenti(conn, idUtente, titoloLetto)) {
                logger.warning("Limite suggerimenti per il libro '" + titoloLetto + "' raggiunto dall'utente: " + username);
                return false;
            }

            if (suggerimentoEsiste(conn, idUtente, titoloLetto, titoloSuggerito)) {
                logger.info("Suggerimento già esistente per utente: " + username);
                return false;
            }

            stmt.setInt(1, idUtente);
            stmt.setString(2, titoloLetto);
            stmt.setString(3, titoloSuggerito);
            stmt.executeUpdate();

            logger.info("Suggerimento inserito con successo: " + titoloLetto + " → " + titoloSuggerito);
            return true;

        } catch (SQLException e) {
            logger.severe("Errore durante l'inserimento del suggerimento: " + e.getMessage());
            return false;
        }
    }
    /**
     * Verifica se un libro esiste nel database dato il suo titolo.
     *
     * @param conn Connessione al database.
     * @param titolo Titolo del libro.
     * @return true se il libro esiste, false altrimenti.
     * @throws SQLException se si verifica un errore SQL.
     */
    private static boolean libroEsiste(Connection conn, String titolo) throws SQLException {
        String sql = "SELECT 1 FROM libri WHERE titolo = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, titolo);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next(); // true se almeno un risultato
            }
        }
    }

    /**
     * Carica tutti i suggerimenti di libri presenti nel database.
     *
     * @return Lista di suggerimenti {@link SuggerimentoLibro}.
     */

    public static List<SuggerimentoLibro> caricaSuggerimenti() { // CARICA TUTTI I SUGGERIMENTI PRESENTI DENTRO IL DB
        List<SuggerimentoLibro> lista = new ArrayList<>();
        String sql = "SELECT u.username, s.letto, s.suggerito FROM suggerimenti s JOIN utenti u ON s.id_utente = u.id";

        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String username = rs.getString("username");
                String letto = rs.getString("letto");
                String suggerito = rs.getString("suggerito");
                lista.add(new SuggerimentoLibro(letto, suggerito, username));
            }

            logger.info("Suggerimenti caricati: " + lista.size());
        } catch (SQLException e) {
            logger.severe("Errore caricamento suggerimenti: " + e.getMessage());
        }

        return lista;
    }
    /**
     * Cerca tutti i suggerimenti dati dagli utenti per un determinato libro letto.
     *
     * @param titoloLetto Titolo del libro letto.
     * @return Lista di suggerimenti {@link SuggerimentoLibro} relativi a quel libro.
     */
    public static List<SuggerimentoLibro> cercaSuggerimentiPerLibroLetto(String titoloLetto) {
        List<SuggerimentoLibro> lista = new ArrayList<>();

        // Pulizia input
        if (titoloLetto == null || titoloLetto.trim().isEmpty()) {
            logger.warning("Titolo letto nullo o vuoto.");
            return lista;
        }

        titoloLetto = titoloLetto.trim();

        try (Connection conn = ConnessioneDB.getConnection()) {

            // Verifica che il libro esista nel database
            if (!libroEsiste(conn, titoloLetto)) {
                logger.warning("Il libro '" + titoloLetto + "' non esiste nel database.");
                return lista;
            }

            String sql = "SELECT u.username, s.letto, s.suggerito " +
                         "FROM suggerimenti s JOIN utenti u ON s.id_utente = u.id " +
                         "WHERE LOWER(s.letto) = LOWER(?)";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, titoloLetto);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        lista.add(new SuggerimentoLibro(
                            rs.getString("letto"),
                            rs.getString("suggerito"),
                            rs.getString("username")
                        ));
                    }
                }
            }

            if (lista.isEmpty()) {
                logger.info("Nessun suggerimento trovato per il libro: " + titoloLetto);
            } else {
            	logger.info("Trovati " + lista.size() + " suggerimenti per il titolo: \"" + titoloLetto + "\".");
            }

        } catch (SQLException e) {
            logger.severe("Errore nella ricerca suggerimenti per '" + titoloLetto + "': " + e.getMessage());
        }

        return lista;
    }
    /**
     * Carica tutti i suggerimenti effettuati da un utente.
     *
     * @param idUtenteStr ID dell’utente (come stringa).
     * @return Lista di suggerimenti effettuati dall’utente.
     */
    public static List<SuggerimentoLibro> caricaSuggerimentiUtente(String idUtenteStr) { // fornisce i suggerimenti in base al libro
        List<SuggerimentoLibro> lista = new ArrayList<>();
        String sql = "SELECT letto, suggerito FROM suggerimenti WHERE id_utente = ?";

        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            int idUtente = Integer.parseInt(idUtenteStr); // converto qui
            stmt.setInt(1, idUtente);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                lista.add(new SuggerimentoLibro(
                    rs.getString("letto"),
                    rs.getString("suggerito"),
                    ""
                ));
            }

        } catch (SQLException | NumberFormatException e) {
            System.err.println("Errore caricamento suggerimenti utente: " + e.getMessage());
        }

        return lista;
    }
    //  METODI DI SUPPORTO 
    /**
     * Ottiene l’ID di un utente a partire dal suo username.
     *
     * @param username Username dell’utente.
     * @return ID dell’utente, oppure -1 se non trovato.
     */
    public static int getIdUtenteDaUsername(String username) { // metodi utili
        try (Connection conn = ConnessioneDB.getConnection()) {
            return getIdUtente(conn, username);
        } catch (SQLException e) {
            logger.severe("Errore ottenimento ID utente: " + e.getMessage());
        }
        return -1;
    }
    
    /**
     * Ottiene l’ID dell’utente dal database.
     *
     * @param conn Connessione attiva al database.
     * @param username Username dell’utente.
     * @return ID utente oppure -1 se non trovato.
     * @throws SQLException se si verifica un errore SQL.
     */
    private static int getIdUtente(Connection conn, String username) throws SQLException {
        String sql = "SELECT id FROM utenti WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() ? rs.getInt("id") : -1;
            }
        }
    }

    /**
     * Ottiene l’ID della libreria dato il nome e l’ID dell’utente.
     *
     * @param conn Connessione al database.
     * @param nome Nome della libreria.
     * @param idUtente ID dell’utente proprietario.
     * @return ID della libreria o -1 se non trovata.
     * @throws SQLException se si verifica un errore SQL.
     */
    private static int getIdLibreria(Connection conn, String nome, int idUtente) throws SQLException {
        String sql = "SELECT id FROM librerie WHERE nome = ? AND id_utente = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setInt(2, idUtente);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getInt("id") : -1;
        }
    }

    /**
     * Ottiene l’ID di un libro dato il suo titolo.
     *
     * @param conn Connessione al database.
     * @param titolo Titolo del libro.
     * @return ID del libro oppure -1 se non trovato.
     * @throws SQLException se si verifica un errore SQL.
     */
    public static int getIdLibro(Connection conn, String titolo) throws SQLException {
        String sql = "SELECT id FROM libri WHERE LOWER(titolo) = LOWER(?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, titolo.trim());
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getInt("id") : -1;
        }
    }

    /**
     * Verifica se un libro è già presente in una libreria.
     *
     * @param conn Connessione al database.
     * @param idLibreria ID della libreria.
     * @param idLibro ID del libro.
     * @return true se il libro è già presente, false altrimenti.
     * @throws SQLException se si verifica un errore SQL.
     */
    private static boolean libroGiaPresente(Connection conn, int idLibreria, int idLibro) throws SQLException { // CHECK
        String sql = "SELECT 1 FROM libri_librerie WHERE id_libreria = ? AND id_libro = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idLibreria);
            stmt.setInt(2, idLibro);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
    
    /**
     * Verifica se un suggerimento esiste già per lo stesso utente e libro.
     *
     * @param conn Connessione al database.
     * @param idUtente ID dell’utente.
     * @param letto Titolo del libro letto.
     * @param suggerito Titolo del libro suggerito.
     * @return true se esiste già, false altrimenti.
     * @throws SQLException se si verifica un errore SQL.
     */

    private static boolean suggerimentoEsiste(Connection conn, int idUtente, String letto, String suggerito) throws SQLException { // CHECK
        String sql = "SELECT 1 FROM suggerimenti WHERE id_utente = ? AND letto = ? AND suggerito = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUtente);
            stmt.setString(2, letto);
            stmt.setString(3, suggerito);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }

}
