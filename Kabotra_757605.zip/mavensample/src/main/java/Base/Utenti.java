/**
 * Classe che rappresenta un utente del sistema.
 * <p>
 * Include informazioni personali e credenziali di accesso, 
 * oltre a metodi statici per la validazione dell'email e del codice fiscale.
 * </p>
 * 
 * <p><strong>Autori:</strong></p>
 * <ul>
 *   <li>Grampa Marco, 758701, Varese (System Architect)</li>
 *   <li>Kabotra Rahul, 757605, Varese (Project Manager)</li>
 *   <li>Morena Matteo, 756150, Varese (Document & Quality Manager)</li>
 *   <li>Colombo Gianluca, 757634, Varese (Design Manager)</li>
 * </ul>
 */
package Base;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utenti implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * Identificatore univoco dell'utente nel database.
     */
    private int id;

    /**
     * Nome dell'utente.
     */
    private String nome;

    /**
     * Cognome dell'utente.
     */
    private String cognome;

    /**
     * Codice fiscale dell'utente.
     */
    private String codiceFiscale;

    /**
     * Indirizzo email dell'utente.
     */
    private String email;

    /**
     * Nome utente per l'accesso al sistema.
     */
    private String userId;

    /**
     * Hash della password dell'utente.
     */
    private String passwordHash;

    /**
     * Costruttore completo dell'oggetto Utenti.
     *
     * @param id            ID numerico del database
     * @param nome          Nome dell'utente
     * @param cognome       Cognome dell'utente
     * @param codiceFiscale Codice fiscale dell'utente
     * @param email         Email dell'utente
     * @param userId        Nome utente (username)
     * @param passwordHash  Hash della password
     */
    public Utenti(int id, String nome, String cognome, String codiceFiscale, String email, String userId, String passwordHash) {
        this.id = id;
        this.nome = nome;
        this.cognome = cognome;
        this.codiceFiscale = codiceFiscale;
        this.email = email;
        this.userId = userId;
        this.passwordHash = passwordHash;
    }

    /**
     * Restituisce l'ID dell'utente.
     * 
     * @return ID numerico dell'utente
     */
    public int getId() {
        return id;
    }

    /**
     * Restituisce il nome dell'utente.
     * 
     * @return Nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Restituisce il cognome dell'utente.
     * 
     * @return Cognome
     */
    public String getCognome() {
        return cognome;
    }

    /**
     * Restituisce l'indirizzo email dell'utente.
     * 
     * @return Email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Restituisce il nome utente (username).
     * 
     * @return Username
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Restituisce il codice fiscale dell'utente.
     * 
     * @return Codice fiscale
     */
    public String getCodiceFiscale() {
        return codiceFiscale;
    }

    /**
     * Restituisce l'hash della password dell'utente.
     * 
     * @return Hash della password
     */
    public String getPasswordHash() {
        return passwordHash;
    }

    /**
     * Restituisce una rappresentazione testuale dell'oggetto Utenti.
     * 
     * @return Rappresentazione CSV dell'utente
     */
    @Override
    public String toString() {
        return id + "," + nome + "," + cognome + "," + codiceFiscale + "," + email + "," + userId + "," + passwordHash;
    }

    /**
     * Ricostruisce un oggetto {@code Utenti} a partire da una stringa serializzata in formato CSV.
     * 
     * @param userString Stringa contenente i dati dell'utente separati da virgole
     * @return Oggetto {@code Utenti} ricostruito
     */
    public static Utenti stringToOggetto(String userString) {
        String[] p = userString.split(",");
        return new Utenti(
            Integer.parseInt(p[0]),
            p[1],
            p[2],
            p[3],
            p[4],
            p[5],
            p[6]
        );
    }

    /**
     * Verifica se l'indirizzo email è valido.
     * 
     * @param mail Indirizzo email da validare
     * @return {@code true} se l'email è valida, altrimenti {@code false}
     */
    public static boolean emailValida(String mail) {
        String regex = "^[\\w.-]+@[\\w.-]+\\.com$";
        return mail.matches(regex);
    }

    /**
     * Verifica se il codice fiscale è valido.
     * 
     * @param codiceFiscale Codice fiscale da validare
     * @return {@code true} se il codice è valido, altrimenti {@code false}
     */
    public static boolean validaCodiceFiscale(String codiceFiscale) {
        if (codiceFiscale == null) return false;
        codiceFiscale = codiceFiscale.toUpperCase().trim();
        return valida(codiceFiscale, CODICE_FISCALE_REGEX) && !tuttiUguali(codiceFiscale);
    }

    /**
     * Espressione regolare per la validazione del codice fiscale.
     */
    private static final String CODICE_FISCALE_REGEX = "^[A-Z]{6}[0-9]{2}[A-EHLMPRST][0-9]{2}[A-Z][0-9]{3}[A-Z]$";

    /**
     * Verifica se tutti i caratteri della stringa sono uguali.
     * 
     * @param s Stringa da analizzare
     * @return {@code true} se tutti i caratteri sono uguali, altrimenti {@code false}
     */
    private static boolean tuttiUguali(String s) {
        if (s.length() < 2) return true;
        char primo = s.charAt(0);
        for (int i = 1; i < s.length(); i++) {
            if (s.charAt(i) != primo) return false;
        }
        return true;
    }

    /**
     * Verifica se una stringa rispetta un'espressione regolare.
     * 
     * @param input Stringa da verificare
     * @param regex Espressione regolare da applicare
     * @return {@code true} se la stringa corrisponde al pattern, altrimenti {@code false}
     */
    private static boolean valida(String input, String regex) {
        if (input == null || input.isEmpty()) return false;
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();
    }
}
