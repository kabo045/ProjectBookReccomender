/* 
 * Grampa, Marco, 758701, Varese, (System architect)
 * Kabotra, Rahul, 757605, Varese, (Project manager)
 * Morena, Matteo, 756150, Varese, (Document & Quality manager)
 * Colombo, Gianluca, 757634, Varese, (Design manager)
 */

package Base;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe di utilità per importare oggetti {@link Libro} da un file serializzato (.dati)
 * e inserirli nel database attraverso il repository {@link RepositoryLibri}.
 * <p>
 * Questa classe è intesa per un uso temporaneo o di migrazione dei dati
 * e non dovrebbe essere usata nel flusso normale dell'applicazione.
 */
public class ImportaLibriNelDB {

    /**
     * Punto di ingresso principale del programma. Legge oggetti {@link Libro}
     * da un file serializzato e li salva nel database.
     *
     * @param args Argomenti da riga di comando (non usati).
     */
    public static void main(String[] args) {
        String filePath = "Libri.dati";
        List<Libro> libri = new ArrayList<>();

        // Lettura del file .dati contenente oggetti Libro serializzati
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            while (true) {
                try {
                    Object obj = ois.readObject();
                    if (obj instanceof Libro libro) {
                        libri.add(libro);
                    }
                } catch (EOFException e) {
                    // Fine del file raggiunta
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Errore durante la lettura del file: " + e.getMessage());
        }

        // Inserimento nel database se la lista non è vuota
        if (!libri.isEmpty()) {
            try {
                RepositoryLibri repo = new RepositoryLibri();
                // Metodo che salva i libri precedentemente caricati nella lista interna del repository
                repo.salvaLibri();
                System.out.println("Libri importati nel database con successo.");
            } catch (Exception e) {
                System.err.println("Errore durante l'inserimento nel database: " + e.getMessage());
            }
        } else {
            System.out.println("Nessun libro è stato letto dal file.");
        }
    }
}
