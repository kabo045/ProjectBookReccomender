/*Grampa, Marco, 758701, Varese, (Systen architect)
Kabotra, Rahul, 757605, Varese,  (Project manager)
Morena, Matteo, 756150, Varese, (Document & quality manager)
Colombo, Gianluca, 757634, Varese,  (Design manager)*/
package Base;

import database.ConnessioneDB;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.logging.Logger;

/**
 * La classe {@code GestioneUtenti} si occupa della gestione delle funzionalità relative agli utenti,
 * come la registrazione, il login e la verifica dell'esistenza degli utenti nel database.
 * Inoltre fornisce metodi per la validazione di dati sensibili (nome, codice fiscale, email)
 * e la protezione delle password tramite hashing SHA-256.
 */
public class GestioneUtenti {
    private static final Logger logger = Logger.getLogger(GestioneUtenti.class.getName());

    /**
     * Registra un nuovo utente nel sistema dopo aver effettuato le opportune validazioni sui campi inseriti.
     *
     * @param nome           Il nome dell'utente.
     * @param cognome        Il cognome dell'utente.
     * @param codiceFiscale  Il codice fiscale dell'utente.
     * @param email          L'indirizzo email dell'utente.
     * @param userId         Lo username scelto per l'accesso.
     * @param password       La password in chiaro da hashare e salvare.
     * @return {@code true} se la registrazione è andata a buon fine, {@code false} altrimenti.
     */
    public static boolean registraDiretto(String nome, String cognome, String codiceFiscale, String email, String userId, String password) {
        if (!nomeValido(nome) || !nomeValido(cognome)) {
            logger.warning("Nome o cognome non validi.");
            return false;
        }
        if (!Utenti.validaCodiceFiscale(codiceFiscale)) {
            logger.warning("Codice fiscale non valido.");
            return false;
        }
        if (!Utenti.emailValida(email)) {
            logger.warning("Email non valida.");
            return false;
        }
        if (utenteEsiste(userId)) {
            logger.warning("Username già in uso.");
            return false;
        }
        if (utenteEsistePerCF(codiceFiscale)) {
            logger.warning("Utente già registrato con questo codice fiscale.");
            return false;
        }

        String hashedPassword = hashPassword(password);

        String sql = "INSERT INTO utenti (nome, cognome, codice_fiscale, email, username, password_hash) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setString(2, cognome);
            stmt.setString(3, codiceFiscale);
            stmt.setString(4, email);
            stmt.setString(5, userId);
            stmt.setString(6, hashedPassword);
            stmt.executeUpdate();

            logger.info("Registrazione completata per utente: " + userId);
            return true;
        } catch (SQLException e) {
            logger.severe("Errore registrazione utente: " + e.getMessage());
            return false;
        }
    }

    /**
     * Esegue il login di un utente verificando le credenziali nel database.
     *
     * @param userId   Lo username dell'utente.
     * @param password La password in chiaro da verificare.
     * @return L'oggetto {@link Utenti} se il login ha successo, {@code null} in caso contrario.
     */
    public static Utenti loginDiretto(String userId, String password) {
        String hashedInput = hashPassword(password);
        String sql = "SELECT * FROM utenti WHERE username = ? AND password_hash = ?";

        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, userId);
            stmt.setString(2, hashedInput);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                logger.info("Login effettuato con successo per: " + userId);
                return new Utenti(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("cognome"),
                    rs.getString("codice_fiscale"),
                    rs.getString("email"),
                    rs.getString("username"),
                    rs.getString("password_hash")
                );
            } else {
                logger.warning("Login fallito: credenziali errate.");
            }
        } catch (SQLException e) {
            logger.severe("Errore SQL durante il login: " + e.getMessage());
        }
        return null;
    }

    /**
     * Verifica se uno username è già presente nel database.
     *
     * @param userId Lo username da controllare.
     * @return {@code true} se l'utente esiste, {@code false} altrimenti.
     */
    public static boolean utenteEsiste(String userId) {
        String sql = "SELECT id FROM utenti WHERE username = ?";
        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, userId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            logger.severe("❌ Errore controllo userId: " + e.getMessage());
            return false;
        }
    }

    /**
     * Verifica se un utente con lo stesso codice fiscale è già registrato.
     *
     * @param codiceFiscale Il codice fiscale da controllare.
     * @return {@code true} se esiste già un utente con quel codice fiscale, {@code false} altrimenti.
     */
    public static boolean utenteEsistePerCF(String codiceFiscale) {
        String sql = "SELECT id FROM utenti WHERE codice_fiscale = ?";
        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, codiceFiscale);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            logger.severe(" Errore controllo codice fiscale: " + e.getMessage());
            return false;
        }
    }

    /**
     * Valida il nome o il cognome di un utente.
     *
     * @param nome Il nome o cognome da validare.
     * @return {@code true} se il nome è valido, {@code false} altrimenti.
     */
    public static boolean nomeValido(String nome) {
        return nome != null && nome.matches("^[A-Za-zÀ-ÖØ-öø-ÿ'\\- ]{2,}$");
    }

    /**
     * Applica l'algoritmo SHA-256 alla password fornita per ottenere un hash sicuro.
     *
     * @param password La password da proteggere.
     * @return La password hashata in formato esadecimale.
     */
    private static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Errore nell'hashing della password", e);
        }
    }
}
