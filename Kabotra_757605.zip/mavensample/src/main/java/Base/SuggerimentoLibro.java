/*Grampa, Marco, 758701, Varese, (Systen architect)
Kabotra, Rahul, 757605, Varese,  (Project manager)
Morena, Matteo, 756150, Varese, (Document & quality manager)
Colombo, Gianluca, 757634, Varese,  (Design manager)*/
package Base;

import java.io.Serializable;

/**
 * Rappresenta un suggerimento di libro, che include il titolo del libro originale, il titolo del libro suggerito e l'ID dell'utente che ha fatto il suggerimento.
 */

public class SuggerimentoLibro implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String titoloLibroOriginale;
    private String titoloLibroSuggerito;
    private String utenteId;

	/**
     * Crea un'istanza di {@code SuggerimentoLibro} con i dati specificati.
     * 
     * @param titoloLibroOriginale Il titolo del libro originale per il quale è stato fatto il suggerimento.
     * @param titoloLibroSuggerito Il titolo del libro suggerito.
     * @param utenteId L'ID dell'utente che ha fatto il suggerimento.
     */

    public SuggerimentoLibro(String titoloLibroOriginale, String titoloLibroSuggerito, String utenteId) {
        this.titoloLibroOriginale = titoloLibroOriginale;
        this.titoloLibroSuggerito = titoloLibroSuggerito;
        this.utenteId = utenteId;
    }
	
	/**
     * Restituisce una rappresentazione in formato stringa del suggerimento del libro.
     * 
     * @return Una stringa che rappresenta il suggerimento del libro nel formato "titoloLibroOriginale|titoloLibroSuggerito|utenteId".
     */

    @Override
    public String toString() {
        return titoloLibroOriginale + "|" + titoloLibroSuggerito + "|" + utenteId;
    }

	public String getTitoloLibroOriginale() {
		return titoloLibroOriginale;
	}

	public void setTitoloLibroOriginale(String titoloLibroOriginale) {
		this.titoloLibroOriginale = titoloLibroOriginale;
	}

	public String getTitoloLibroSuggerito() {
		return titoloLibroSuggerito;
	}

	public void setTitoloLibroSuggerito(String titoloLibroSuggerito) {
		this.titoloLibroSuggerito = titoloLibroSuggerito;
	}

	public String getUtenteId() {
		return utenteId;
	}

	public void setUtenteId(String utenteId) {
		this.utenteId = utenteId;
	}
    
}
