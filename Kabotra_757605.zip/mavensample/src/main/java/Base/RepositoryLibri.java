/**
 * Classe responsabile per la gestione dei libri e delle valutazioni nel sistema.
 * Fornisce metodi per caricare, salvare, cercare e manipolare dati relativi a libri e valutazioni.
 * 
 * @author Grampa, Marco (System Architect)
 * @author Kabotra, Rahul (Project Manager)
 * @author Morena, Matteo (Document & Quality Manager)
 * @author Colombo, Gianluca (Design Manager)
 * @version 1.0
 * @package Base
 */
package Base;

import database.ConnessioneDB;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class RepositoryLibri {
    private static final Logger logger = Logger.getLogger(RepositoryLibri.class.getName());

    private final List<Libro> libri;
    private final List<Valutazione> valutazioni;

    /**
     * Costruttore che inizializza le liste per libri e valutazioni.
     * Utilizza CopyOnWriteArrayList per garantire thread-safety.
     */
    public RepositoryLibri() {
        this.libri = new CopyOnWriteArrayList<>();
        this.valutazioni = new CopyOnWriteArrayList<>();
    }

    //  CARICAMENTO E SALVATAGGIO

    /**
     * Carica tutti i libri dal database nella lista interna.
     * Svuota la lista corrente prima del caricamento.
     * Logga il numero di libri caricati o eventuali errori.
     */
    public synchronized void caricaLibri() {
        libri.clear();
        String sql = "SELECT * FROM libri";
        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Libro libro = new Libro(
                    rs.getString("titolo"),
                    rs.getString("autore"),
                    rs.getInt("anno_pubblicazione"),
                    rs.getString("editore"),
                    rs.getString("categoria")
                );
                libri.add(libro);
            }

            logger.info("Libri caricati dal database: " + libri.size());
        } catch (SQLException e) {
            logger.severe("Errore caricamento libri: " + e.getMessage());
        }
    }

    /**
     * Salva i libri presenti nella lista interna nel database.
     * Utilizza un batch update per ottimizzare le operazioni.
     * Ignora conflitti su titolo e autore già esistenti.
     */
    public synchronized void salvaLibri() {
        String sql = """
            INSERT INTO libri (titolo, autore, descrizione, categoria, editore, mese_pubblicazione, anno_pubblicazione)
            VALUES (?, ?, '', ?, ?, '', ?)
            ON CONFLICT (titolo, autore) DO NOTHING
            """;
        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            for (Libro libro : libri) {
                stmt.setString(1, libro.getTitolo());
                stmt.setString(2, libro.getAutori());
                stmt.setString(3, libro.getCategoria());
                stmt.setString(4, libro.getEditore());
                stmt.setInt(5, libro.getAnnoPubblicazione());
                stmt.addBatch();
            }

            stmt.executeBatch();
            logger.info("Libri salvati nel database.");
        } catch (SQLException e) {
            logger.severe("Errore salvataggio libri: " + e.getMessage());
        }
    }

    /**
     * Carica libri da un file CSV con formato specifico.
     * 
     * @param percorsoFile il percorso del file da cui caricare i libri
     */
    public synchronized void caricaDaFile(String percorsoFile) {
        try (BufferedReader reader = new BufferedReader(new FileReader(percorsoFile))) {
            String riga;
            int righeIgnorate = 0;
            while ((riga = reader.readLine()) != null) {
                try {
                    String[] campi = riga.split(";", -1);
                    String titolo = campi.length > 0 ? campi[0].trim() : "";
                    String autore = campi.length > 1 ? campi[1].trim() : "";
                    String annoStr = campi.length > 2 ? campi[2].trim() : "";
                    String editore = campi.length > 3 ? campi[3].trim() : "Sconosciuto";
                    String categoria = campi.length > 4 ? campi[4].trim() : "Sconosciuta";

                    if (titolo.isEmpty() || autore.isEmpty()) {
                        righeIgnorate++;
                        continue;
                    }

                    int anno;
                    try {
                        anno = Integer.parseInt(annoStr);
                    } catch (NumberFormatException e) {
                        anno = -1;
                    }

                    Libro libro = new Libro(titolo, autore, anno, editore, categoria);
                    if (!libri.contains(libro)) {
                        libri.add(libro);
                    }
                } catch (Exception e) {
                    righeIgnorate++;
                }
            }

            logger.info("Libri caricati da file: " + libri.size());
            if (righeIgnorate > 0) {
                logger.warning("Righe ignorate (dati fondamentali mancanti): " + righeIgnorate);
            }
        } catch (IOException e) {
            logger.severe(" Errore durante la lettura del file: " + e.getMessage());
        }
    }

    /**
     * Carica i libri associati a una specifica libreria.
     * 
     * @param conn la connessione al database
     * @param idLibreria l'ID della libreria da cui caricare i libri
     * @return una lista di libri presenti nella libreria specificata
     */
    public static List<Libro> caricaLibriPerLibreria(Connection conn, int idLibreria) {
        List<Libro> libri = new ArrayList<>();
        String sql = "SELECT titolo, autore, anno FROM libri WHERE id_libreria = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idLibreria);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String titolo = rs.getString("titolo");
                    String autore = rs.getString("autore");
                    int anno = rs.getInt("anno");
                    libri.add(new Libro(titolo, autore, anno, "", ""));
                }
            }

        } catch (SQLException e) {
            System.err.println("❌ Errore nel caricamento libri per libreria ID " + idLibreria + ": " + e.getMessage());
        }

        return libri;
    }

    /**
     * Carica tutte le valutazioni dal database.
     * Svuota la lista corrente prima del caricamento.
     */
    public void caricaValutazioni() {
        valutazioni.clear();

        String sql = """
            SELECT v.*, u.username AS nome_utente, l.titolo AS titolo_libro
            FROM valutazioni v
            JOIN utenti u ON v.id_utente = u.id
            JOIN libri l ON v.id_libro = l.id
        """;

        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Valutazione v = new Valutazione(
                    rs.getString("nome_utente"),
                    rs.getString("titolo_libro"),
                    rs.getInt("stile"),
                    rs.getString("nota_stile"),
                    rs.getInt("contenuto"),
                    rs.getString("nota_contenuto"),
                    rs.getInt("gradevolezza"),
                    rs.getString("nota_gradevolezza"),
                    rs.getInt("originalita"),
                    rs.getString("nota_originalita"),
                    rs.getInt("edizione"),
                    rs.getString("nota_edizione"),
                    rs.getInt("voto_finale"),
                    rs.getString("nota_generale")
                );

                valutazioni.add(v);
            }

        } catch (SQLException e) {
            System.out.println("Errore caricamento valutazioni: " + e.getMessage());
        }
    }

    /**
     * Inserisce una nuova valutazione nel database.
     * 
     * @param v l'oggetto Valutazione da inserire
     * @return true se l'inserimento è avvenuto con successo, false altrimenti
     */
    public boolean inserisciValutazione(Valutazione v) {
        String trovaLibroSql = "SELECT id FROM libri WHERE LOWER(titolo) = LOWER(?)";
        String trovaUtenteSql = "SELECT id FROM utenti WHERE LOWER(username) = LOWER(?)";
        String inserisciSql = """
            INSERT INTO valutazioni (
                id_libro, id_utente, stile, nota_stile, contenuto, nota_contenuto,
                gradevolezza, nota_gradevolezza, originalita, nota_originalita,
                edizione, nota_edizione, voto_finale, nota_generale
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = ConnessioneDB.getConnection()) {
            // Trova ID libro
            int idLibro;
            try (PreparedStatement stmt = conn.prepareStatement(trovaLibroSql)) {
                stmt.setString(1, v.getTitoloLibro());
                ResultSet rs = stmt.executeQuery();
                if (!rs.next()) {
                    System.out.println("Libro non trovato.");
                    return false;
                }
                idLibro = rs.getInt("id");
            }

            // Trova ID utente
            int idUtente;
            try (PreparedStatement stmt = conn.prepareStatement(trovaUtenteSql)) {
                stmt.setString(1, v.getUtenteId());
                ResultSet rs = stmt.executeQuery();
                if (!rs.next()) {
                    System.out.println("Utente non trovato.");
                    return false;
                }
                idUtente = rs.getInt("id");
            }

            // Inserisci valutazione
            try (PreparedStatement stmt = conn.prepareStatement(inserisciSql)) {
                stmt.setInt(1, idLibro);
                stmt.setInt(2, idUtente);
                stmt.setInt(3, v.getStile());
                stmt.setString(4, v.getNotaStile());
                stmt.setInt(5, v.getContenuto());
                stmt.setString(6, v.getNotaContenuto());
                stmt.setInt(7, v.getGradevolezza());
                stmt.setString(8, v.getNotaGradevolezza());
                stmt.setInt(9, v.getOriginalita());
                stmt.setString(10, v.getNotaOriginalita());
                stmt.setInt(11, v.getEdizione());
                stmt.setString(12, v.getNotaEdizione());
                stmt.setInt(13, v.getVotoFinale());
                stmt.setString(14, v.getNotaGenerale());

                stmt.executeUpdate();
            }

            System.out.println("Valutazione inserita con successo.");
            return true;

        } catch (SQLException e) {
            System.out.println("Errore inserimento valutazione: " + e.getMessage());
            return false;
        }
    }

    //  OPERAZIONI CRUD

    /**
     * Aggiunge un libro a una specifica libreria.
     * 
     * @param libro il libro da aggiungere
     * @param idLibreria l'ID della libreria a cui aggiungere il libro
     */
    public void aggiungiLibroALibreria(Libro libro, int idLibreria) {
        String insertLibroSql = """
            INSERT INTO libri (titolo, autore, descrizione, categoria, editore, mese_pubblicazione, anno_pubblicazione)
            VALUES (?, ?, '', ?, ?, '', ?)
            ON CONFLICT (titolo, autore) DO NOTHING
            RETURNING id
        """;

        String selectLibroIdSql = "SELECT id FROM libri WHERE titolo = ? AND autore = ?";
        String insertAssociazioneSql = "INSERT INTO libri_librerie (id_libreria, id_libro) VALUES (?, ?) ON CONFLICT DO NOTHING";

        try (Connection conn = ConnessioneDB.getConnection()) {
            int libroId = -1;

            //  Inserisci (o recupera) libro
            try (PreparedStatement stmt = conn.prepareStatement(insertLibroSql)) {
                stmt.setString(1, libro.getTitolo());
                stmt.setString(2, libro.getAutori());
                stmt.setString(3, libro.getCategoria());
                stmt.setString(4, libro.getEditore());
                stmt.setInt(5, libro.getAnnoPubblicazione());

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        libroId = rs.getInt("id");
                    }
                }
            }

            // Se il libro già esiste, recupera l'id
            if (libroId == -1) {
                try (PreparedStatement stmt = conn.prepareStatement(selectLibroIdSql)) {
                    stmt.setString(1, libro.getTitolo());
                    stmt.setString(2, libro.getAutori());
                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next()) {
                            libroId = rs.getInt("id");
                        } else {
                            throw new SQLException("Libro non trovato dopo inserimento.");
                        }
                    }
                }
            }

            // Collega il libro alla libreria
            try (PreparedStatement stmt = conn.prepareStatement(insertAssociazioneSql)) {
                stmt.setInt(1, idLibreria);
                stmt.setInt(2, libroId);
                stmt.executeUpdate();
            }

            System.out.println("Libro collegato alla libreria con ID: " + idLibreria);

        } catch (SQLException e) {
            System.err.println("Errore durante l'aggiunta del libro alla libreria: " + e.getMessage());
        }
    }

    /**
     * Carica tutte le valutazioni dal database nella lista interna.
     * Svuota la lista corrente prima del caricamento.
     */
    public synchronized void caricaValutazioniDaDatabase() {
        valutazioni.clear();

        String sql = "SELECT v.*, l.titolo, u.username " +
                     "FROM valutazioni v " +
                     "JOIN libri l ON v.id_libro = l.id " +
                     "JOIN utenti u ON v.id_utente = u.id";

        try (Connection conn = ConnessioneDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Valutazione v = new Valutazione(
                    rs.getString("username"),
                    rs.getString("titolo"),
                    rs.getInt("stile"), rs.getString("nota_stile"),
                    rs.getInt("contenuto"), rs.getString("nota_contenuto"),
                    rs.getInt("gradevolezza"), rs.getString("nota_gradevolezza"),
                    rs.getInt("originalita"), rs.getString("nota_originalita"),
                    rs.getInt("edizione"), rs.getString("nota_edizione"),
                    rs.getInt("voto_finale"), rs.getString("nota_generale")
                );
                valutazioni.add(v);
            }

            logger.info("Valutazioni caricate: " + valutazioni.size());

        } catch (SQLException e) {
            logger.severe("Errore durante il caricamento valutazioni: " + e.getMessage());
        }
    }

    /**
     * Calcola le medie delle valutazioni per ogni libro.
     * 
     * @return una mappa con titolo del libro come chiave e una mappa di categorie/valori medi
     */
    public synchronized Map<String, Map<String, Double>> calcolaMediaValutazioniPerLibro() {
        Map<String, Map<String, List<Integer>>> accumulator = new HashMap<>();

        for (Valutazione v : valutazioni) {
            String titolo = v.getTitoloLibro();
            accumulator.putIfAbsent(titolo, new HashMap<>());

            Map<String, List<Integer>> categorie = accumulator.get(titolo);
            categorie.computeIfAbsent("Stile", k -> new ArrayList<>()).add(v.getStile());
            categorie.computeIfAbsent("Contenuto", k -> new ArrayList<>()).add(v.getContenuto());
            categorie.computeIfAbsent("Gradevolezza", k -> new ArrayList<>()).add(v.getGradevolezza());
            categorie.computeIfAbsent("Originalità", k -> new ArrayList<>()).add(v.getOriginalita());
            categorie.computeIfAbsent("Edizione", k -> new ArrayList<>()).add(v.getEdizione());
            categorie.computeIfAbsent("Voto Finale", k -> new ArrayList<>()).add(v.getVotoFinale());
        }

        Map<String, Map<String, Double>> medieFinali = new HashMap<>();

        for (Map.Entry<String, Map<String, List<Integer>>> entry : accumulator.entrySet()) {
            String titolo = entry.getKey();
            Map<String, List<Integer>> catVals = entry.getValue();
            Map<String, Double> medie = new HashMap<>();

            for (Map.Entry<String, List<Integer>> cat : catVals.entrySet()) {
                double media = cat.getValue().stream().mapToInt(Integer::intValue).average().orElse(0.0);
                medie.put(cat.getKey(), media);
            }

            medieFinali.put(titolo, medie);
        }

        return medieFinali;
    }

    //  RICERCA

    /**
     * Cerca libri per titolo (case insensitive, ricerca parziale).
     * 
     * @param titolo il titolo (o parte di esso) da cercare
     * @return una lista di libri che corrispondono alla ricerca
     */
    public synchronized List<Libro> cercaLibroPerTitolo(String titolo) {
        if (titolo == null || titolo.isBlank()) return List.of();
        String titoloLower = titolo.toLowerCase();

        return libri.stream()
            .filter(l -> l.getTitolo() != null && l.getTitolo().toLowerCase().contains(titoloLower))
            .collect(Collectors.toMap(
                l -> l.getTitolo().toLowerCase() + "|" + l.getAutori().toLowerCase(),
                l -> l,
                (existing, replacement) -> existing))
            .values().stream().toList();
    }

    /**
     * Cerca libri per autore (case insensitive, ricerca parziale).
     * 
     * @param autore l'autore (o parte di esso) da cercare
     * @return una lista di libri che corrispondono alla ricerca
     */
    public synchronized List<Libro> cercaLibroPerAutore(String autore) {
        if (autore == null || autore.isBlank()) return List.of();
        String autoreLower = autore.toLowerCase();

        return libri.stream()
            .filter(l -> l.getAutori() != null && l.getAutori().toLowerCase().contains(autoreLower))
            .collect(Collectors.toMap(
                l -> l.getTitolo().toLowerCase() + "|" + l.getAutori().toLowerCase(),
                l -> l,
                (existing, replacement) -> existing))
            .values().stream().toList();
    }

    /**
     * Cerca libri per combinazione autore e anno.
     * 
     * @param autore l'autore (o parte di esso) da cercare
     * @param anno l'anno di pubblicazione da cercare
     * @return una lista di libri che corrispondono alla ricerca
     */
    public synchronized List<Libro> cercaLibroPerAutoreAnno(String autore, int anno) {
        if (autore == null || autore.isBlank() || anno <= 0) return List.of();
        String query = (autore + " " + anno).toLowerCase();

        return libri.stream()
            .filter(l -> {
                String autori = l.getAutori() != null ? l.getAutori().toLowerCase() : "";
                int annoPubblicazione = l.getAnnoPubblicazione();
                String combinazione = (autori + " " + annoPubblicazione).toLowerCase();
                return combinazione.contains(query);
            })
            .collect(Collectors.toMap(
                l -> l.getTitolo().toLowerCase() + "|" + l.getAutori().toLowerCase(),
                l -> l,
                (existing, replacement) -> existing))
            .values().stream().toList();
    }

    //  VISUALIZZAZIONE DETTAGLIATA

    /**
     * Visualizza i dettagli completi di un libro, incluse valutazioni medie e note.
     * 
     * @param titolo il titolo del libro da visualizzare (ricerca parziale, case insensitive)
     */
    public synchronized void visualizzaLibro(String titolo) {
        try (Connection conn = ConnessioneDB.getConnection()) {
            String libroSql = "SELECT * FROM libri WHERE LOWER(titolo) LIKE LOWER(?)";
            PreparedStatement libroStmt = conn.prepareStatement(libroSql);
            libroStmt.setString(1, "%" + titolo.trim().toLowerCase() + "%");
            ResultSet libroRs = libroStmt.executeQuery();

            if (!libroRs.next()) {
                System.out.println("Libro non trovato.");
                return;
            }

            System.out.println("\n--- Dettagli del Libro ---");
            System.out.println("Titolo: " + libroRs.getString("titolo"));
            System.out.println("Autore: " + libroRs.getString("autore"));
            System.out.println("Anno: " + libroRs.getInt("anno_pubblicazione"));
            System.out.println("Editore: " + libroRs.getString("editore"));
            System.out.println("Categoria: " + libroRs.getString("categoria"));

            int idLibro = libroRs.getInt("id");

            // Valutazioni medie
            String mediaSql = """
                SELECT AVG(stile) AS media_stile, AVG(contenuto) AS media_contenuto,
                       AVG(gradevolezza) AS media_gradevolezza, AVG(originalita) AS media_originalita,
                       AVG(edizione) AS media_edizione, AVG(voto_finale) AS media_finale
                FROM valutazioni WHERE id_libro = ?
            """;

            PreparedStatement mediaStmt = conn.prepareStatement(mediaSql);
            mediaStmt.setInt(1, idLibro);
            ResultSet mediaRs = mediaStmt.executeQuery();

            System.out.println("\n--- Valutazioni medie ---");
            if (mediaRs.next()) {
                System.out.printf("Stile: %.2f%n", mediaRs.getDouble("media_stile"));
                System.out.printf("Contenuto: %.2f%n", mediaRs.getDouble("media_contenuto"));
                System.out.printf("Gradevolezza: %.2f%n", mediaRs.getDouble("media_gradevolezza"));
                System.out.printf("Originalità: %.2f%n", mediaRs.getDouble("media_originalita"));
                System.out.printf("Edizione: %.2f%n", mediaRs.getDouble("media_edizione"));
                System.out.printf("Voto Finale: %.2f%n", mediaRs.getDouble("media_finale"));
            } else {
                System.out.println("Nessuna valutazione disponibile.");
            }

            // Note
            String noteSql = """
                SELECT nota_stile, nota_contenuto, nota_gradevolezza, nota_originalita,
                       nota_edizione, nota_generale
                FROM valutazioni WHERE id_libro = ?
            """;

            PreparedStatement noteStmt = conn.prepareStatement(noteSql);
            noteStmt.setInt(1, idLibro);
            ResultSet noteRs = noteStmt.executeQuery();

            int count = 1;
            boolean almenoUnaNota = false;
            while (noteRs.next()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Valutazione #").append(count++).append("\n");

                if (!noteRs.getString("nota_stile").isBlank())
                    sb.append("• Stile: ").append(noteRs.getString("nota_stile")).append("\n");
                if (!noteRs.getString("nota_contenuto").isBlank())
                    sb.append("• Contenuto: ").append(noteRs.getString("nota_contenuto")).append("\n");
                if (!noteRs.getString("nota_gradevolezza").isBlank())
                    sb.append("• Gradevolezza: ").append(noteRs.getString("nota_gradevolezza")).append("\n");
                if (!noteRs.getString("nota_originalita").isBlank())
                    sb.append("• Originalità: ").append(noteRs.getString("nota_originalita")).append("\n");
                if (!noteRs.getString("nota_edizione").isBlank())
                    sb.append("• Edizione: ").append(noteRs.getString("nota_edizione")).append("\n");
                if (!noteRs.getString("nota_generale").isBlank())
                    sb.append("• Nota Generale: ").append(noteRs.getString("nota_generale")).append("\n");

                if (sb.length() > 0) {
                    System.out.println("\n" + sb);
                    almenoUnaNota = true;
                }
            }

            if (!almenoUnaNota) {
                System.out.println("\nNessuna nota disponibile.");
            }

        } catch (SQLException e) {
            System.out.println("Errore durante la visualizzazione: " + e.getMessage());
        }
    }

    // GETTER

    /**
     * Restituisce una copia della lista dei libri.
     * 
     * @return una lista contenente tutti i libri
     */
    public synchronized List<Libro> getLibri() {
        return new ArrayList<>(libri);
    }

    /**
     * Restituisce una copia della lista delle valutazioni.
     * 
     * @return una lista contenente tutte le valutazioni
     */
    public List<Valutazione> getValutazioni() {
        return new ArrayList<>(valutazioni);
    }
}