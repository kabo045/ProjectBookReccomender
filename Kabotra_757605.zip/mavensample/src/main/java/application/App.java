package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import database.ConnessioneDB;

/**
 * Classe principale dell'applicazione JavaFX.
 * Si occupa di:
 * - Inizializzare la connessione al database chiedendo i parametri all'utente.
 * - Caricare e visualizzare l'interfaccia grafica principale (main.fxml).
 */
public class App extends Application {

    @Override
    public void start(Stage primaryStage) {
        // NON avviare il server qui! Va eseguito separatamente tramite server.jar

        // Carica l'interfaccia grafica
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/views/main.fxml"));
            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Benvenuto!");
            primaryStage.show();
        } catch (Exception e) {
            System.err.println("Errore durante il caricamento della GUI:");
            e.printStackTrace();
        }
    }

/**
 * Metodo main dell'applicazione.
 * Richiede i parametri di connessione al database e avvia l'interfaccia JavaFX.
 *
 * @param args argomenti da linea di comando (non utilizzati)
 */

    public static void main(String[] args) {
    	ConnessioneDB.setupConnectionParams(); // 👈 IMPORTANTE!
        launch(args);  // Avvia JavaFX
    }
}



