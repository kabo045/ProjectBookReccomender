/**
 * Classe SlaveThread gestisce la comunicazione lato server con un singolo client.
 * Estende {@link Thread} e si occupa di ricevere richieste da un client connesso
 * tramite socket e rispondere adeguatamente utilizzando gli oggetti forniti come
 * parametri di supporto alla gestione utenti, libri e librerie.
 *
 * Autori:
 * - Grampa Marco (System Architect)
 * - Kabotra Rahul (Project Manager)
 * - Morena Matteo (Document & Quality Manager)
 * - Colombo Gianluca (Design Manager)
 *
 * Package: Networking
 */
package Networking;

import java.io.*;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import Base.*;
import database.ConnessioneDB;

public class SlaveThread extends Thread {

    private final Socket socket;
    private final GestioneLibreria libreria;
    private final GestioneUtenti utenti;
    private final RepositoryLibri repository;

    private ObjectOutputStream out;
    private ObjectInputStream in;

    /**
     * Costruttore della classe SlaveThread.
     *
     * @param s Socket client connesso
     * @param l GestioneLibreria per operazioni su librerie
     * @param u GestioneUtenti per operazioni su utenti
     * @param r RepositoryLibri per operazioni di ricerca e accesso ai dati libro
     */
    public SlaveThread(Socket s, GestioneLibreria l, GestioneUtenti u, RepositoryLibri r) {
        this.socket = s;
        this.libreria = l;
        this.utenti = u;
        this.repository = r;

        try {
            // Ordine corretto: prima output, poi input stream
            this.out = new ObjectOutputStream(socket.getOutputStream());
            this.in = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            System.err.println("Errore inizializzazione stream: " + e.getMessage());
        }
    }

    /**
     * Metodo eseguito dal thread. Gestisce l'intera comunicazione con il client.
     * Interpreta i comandi ricevuti e invoca i relativi metodi per gestire utenti,
     * librerie, libri, suggerimenti, valutazioni ecc.
     */
    @Override
    public void run() {
        try {
            System.out.println("Connessione attiva con client: " + socket.getInetAddress());

            while (!socket.isClosed()) {
                Messaggio richiesta = (Messaggio) in.readObject();
                String comando = richiesta.getComando();
                System.out.println("Ricevuto comando: " + comando);

                switch (comando) {
                    case "end" -> {
                        // Disconnessione richiesta dal client
                        System.out.println("Disconnessione richiesta dal client.");
                        socket.close();
                        return;
                    }

                    case "ping" -> {
                        // Risposta semplice di tipo ping-pong per test connessione
                        out.writeObject(new Messaggio("pong", "OK"));
                    }

                    case "login" -> {
                        try {
                            // Login utente diretto
                            String[] credenziali = (String[]) richiesta.getContenuto();
                            Utenti utente = GestioneUtenti.loginDiretto(credenziali[0], credenziali[1]);
                            out.writeObject(new Messaggio("risposta_login", utente));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore login: " + e.getMessage()));
                        }
                    }

                    case "registrazione" -> {
                        try {
                            // Registrazione nuovo utente
                            String[] dati = (String[]) richiesta.getContenuto();
                            boolean esito = GestioneUtenti.registraDiretto(
                                    dati[0], dati[1], dati[2], dati[3], dati[4], dati[5]);
                            out.writeObject(new Messaggio("risposta_registrazione", esito));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore registrazione: " + e.getMessage()));
                        }
                    }

                    case "ricerca_titolo" -> {
                        try {
                            // Ricerca libro per titolo
                            String titolo = (String) richiesta.getContenuto();
                            List<Libro> risultati = repository.cercaLibroPerTitolo(titolo);
                            if (risultati == null) risultati = List.of();
                            out.writeObject(new Messaggio("risposta_ricerca_titolo", risultati));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore ricerca titolo: " + e.getMessage()));
                        }
                    }

                    case "ricerca_autore" -> {
                        try {
                            // Ricerca libro per autore
                            String autore = (String) richiesta.getContenuto();
                            List<Libro> risultati = repository.cercaLibroPerAutore(autore);
                            if (risultati == null) risultati = List.of();
                            out.writeObject(new Messaggio("risposta_ricerca_autore", risultati));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore ricerca autore: " + e.getMessage()));
                        }
                    }

                    case "ricerca_autore_anno" -> {
                        try {
                            // Ricerca combinata autore e anno
                            Object[] dati = (Object[]) richiesta.getContenuto();
                            String autore = (String) dati[0];
                            int anno = (int) dati[1];
                            List<Libro> risultati = repository.cercaLibroPerAutoreAnno(autore, anno);
                            if (risultati == null) risultati = List.of();
                            out.writeObject(new Messaggio("risposta_ricerca_autore_anno", risultati));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore ricerca autore/anno: " + e.getMessage()));
                        }
                    }

                    case "visualizza_dettagli" -> {
                        try {
                            // Visualizza dettagli di un libro come testo
                            String titolo = (String) richiesta.getContenuto();
                            String risultato = GestioneLibreria.visualizzaLibroComeTesto(titolo);
                            out.writeObject(new Messaggio("ok", risultato));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore visualizzazione: " + e.getMessage()));
                        }
                    }

                    case "lista_libri" -> {
                        try (Connection conn = ConnessioneDB.getConnection();
                             PreparedStatement stmt = conn.prepareStatement("""
                                 SELECT DISTINCT l.titolo
                                 FROM libri l
                                 JOIN valutazioni v ON l.id = v.id_libro
                             """);
                             ResultSet rs = stmt.executeQuery()) {

                            // Restituisce titoli di libri valutati
                            List<String> titoli = new ArrayList<>();
                            while (rs.next()) {
                                titoli.add(rs.getString("titolo"));
                            }

                            out.writeObject(new Messaggio("ok", titoli));

                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore caricamento libri valutati: " + e.getMessage()));
                        }
                    }

                    case "crea_libreria" -> {
                        try {
                            // Crea una nuova libreria personale per un utente
                            Object[] dati = (Object[]) richiesta.getContenuto();
                            String nome = (String) dati[0];
                            String userId = (String) dati[1];
                            int userIntId = GestioneLibreria.getIdUtenteDaUsername(userId);
                            GestioneLibreria.registraLibreria(new Libreria(nome, userIntId));
                            out.writeObject(new Messaggio("ok", true));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore creazione libreria: " + e.getMessage()));
                        }
                    }

                    case "aggiungi_libro" -> {
                        try {
                            // Aggiunge un libro a una libreria
                            Object[] dati = (Object[]) richiesta.getContenuto();
                            String userId = (String) dati[0];
                            String nomeLibreria = (String) dati[1];
                            String titoloLibro = (String) dati[2];
                            GestioneLibreria.aggiungiLibroALibreria(nomeLibreria, userId, titoloLibro);
                            out.writeObject(new Messaggio("ok", true));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore aggiunta libro: " + e.getMessage()));
                        }
                    }

                    case "cerca_libro" -> {
                        // Ricerca fuzzy di un libro (approssimativa)
                        String titolo = (String) richiesta.getContenuto();
                        try (Connection conn = ConnessioneDB.getConnection()) {
                            Map<String, Integer> trovati = GestioneLibreria.cercaLibriFuzzy(conn, titolo);
                            if (trovati.isEmpty()) {
                                out.writeObject(new Messaggio("risposta", -1));
                            } else {
                                // Per semplicità, viene restituito solo il primo risultato
                                out.writeObject(new Messaggio("risposta", trovati.values().iterator().next()));
                            }
                       
                        } catch (Exception ex) {
                            out.writeObject(new Messaggio("errore", -1));
                        }
                    }

                    case "valutazione_libro" -> {
                        try {
                            // Inserisce una valutazione per un libro da parte di un utente
                            Object[] d = (Object[]) richiesta.getContenuto();

                            String userId = (String) d[0];
                            int idLibro = (int) d[1];

                            // Voti per diverse categorie
                            int stile = (int) d[2];
                            int contenuto = (int) d[3];
                            int gradevolezza = (int) d[4];
                            int originalita = (int) d[5];
                            int edizione = (int) d[6];
                            int votoFinale = (int) d[7];

                            // Nota testuale finale dell'utente
                            String notaFinale = (String) d[8];

                            // Inserimento valutazione nel sistema
                            boolean esito = GestioneLibreria.inserisciValutazioneLibro(
                                userId, idLibro,
                                stile, "", contenuto, "", gradevolezza, "",
                                originalita, "", edizione, "", votoFinale, notaFinale
                            );

                            out.writeObject(new Messaggio(esito ? "ok" : "errore", esito));

                        } catch (Exception e) {
                            e.printStackTrace();
                            out.writeObject(new Messaggio("errore", "Errore valutazione: " + e.getMessage()));
                        }
                    }

                    case "aggiungi_suggerimento" -> {
                        try {
                            // Inserisce un suggerimento di libro da parte di un utente
                            Object[] s = (Object[]) richiesta.getContenuto();
                            boolean esito = GestioneLibreria.inserisciSuggerimentoLibro(
                                    (String) s[0], (String) s[1], (String) s[2]);
                            out.writeObject(new Messaggio(esito ? "ok" : "errore", esito));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore suggerimento: " + e.getMessage()));
                        }
                    }

                    case "visualizza_suggerimenti" -> {
                        try {
                            // Carica tutti i suggerimenti di libri presenti nel sistema
                            List<SuggerimentoLibro> suggerimenti = GestioneLibreria.caricaSuggerimenti();
                            out.writeObject(new Messaggio("ok", suggerimenti));
                        } catch (Exception e) {
                            out.writeObject(new Messaggio("errore", "Errore caricamento suggerimenti: " + e.getMessage()));
                        }
                    }

                    default -> {
                        // Comando sconosciuto o non gestito
                        System.err.println("❓ Comando non riconosciuto: " + comando);
                        out.writeObject(new Messaggio("errore", "Comando non riconosciuto: " + comando));
                    }
                }
            }

        } catch (EOFException eof) {
            // Il client ha chiuso la connessione
            System.out.println("Connessione chiusa dal client.");
        } catch (IOException | ClassNotFoundException e) {
            // Errore generico di comunicazione
            System.err.println("Errore durante la comunicazione: " + e.getMessage());
        } finally {
            try {
                // Tentativo di chiusura della socket alla fine della sessione
                socket.close();
                System.out.println("Socket chiuso.");
            } catch (IOException e) {
                System.err.println("Errore chiusura socket: " + e.getMessage());
            }
        }
    }
}
