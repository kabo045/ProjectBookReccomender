package Networking;

import java.io.*;
import java.net.*;
import java.util.*;

import Base.Messaggio;
import Base.Utenti;

/**
 * Classe Client per la gestione della connessione e comunicazione con il server
 * del sistema bibliotecario. Comunica solo via socket.
 */
public class Client {
    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private Scanner scanner;

    public Client() throws IOException {
        InetAddress serverAddress = InetAddress.getByName(null); // localhost
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.socket = new Socket(serverAddress, 8999);
        this.out = new ObjectOutputStream(socket.getOutputStream());
        this.in = new ObjectInputStream(socket.getInputStream());
        this.scanner = new Scanner(System.in);
        System.out.println("\u2705 Connessione al server stabilita.");
    }

    public Messaggio inviaRichiesta(Messaggio richiesta) {
        try {
            out.writeObject(richiesta);
            out.flush();
            Object risposta = in.readObject();
            if (risposta instanceof Messaggio msg) {
                return msg;
            } else {
                return new Messaggio("errore", "Tipo risposta non valido: " + (risposta != null ? risposta.getClass() : "null"));
            }
        } catch (IOException | ClassNotFoundException e) {
            return new Messaggio("errore", "Errore di comunicazione: " + e.getMessage());
        }
    }

    public void chiudi() {
        try {
            out.writeObject(new Messaggio("end", null));
            out.flush();
            socket.close();
            System.out.println("\ud83d\udd0c Connessione chiusa.");
        } catch (IOException e) {
            System.err.println("Errore chiusura client: " + e.getMessage());
        }
    }

    public void menu() {
        String usernameLoggato = null;

        while (true) {
            System.out.println("""
                \n\ud83d\udcda Menu:
                1. Login
                2. Registrazione
                3. Ricerca libro per titolo
                4. Ricerca libro per autore
                5. Ricerca per autore e anno
                6. Visualizza dettagli libro
                7. Crea libreria
                8. Aggiungi libro a libreria
                9. Valuta libro
                10. Aggiungi suggerimento
                11. Visualizza suggerimenti
                0. Esci
                \u27a4 Scegli un'opzione:""");

            String input = scanner.nextLine();
            int scelta;
            try {
                scelta = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Inserisci un numero valido.");
                continue;
            }

            switch (scelta) {
                case 1 -> {
                    System.out.print("Username: ");
                    String user = scanner.nextLine();
                    System.out.print("Password: ");
                    String pass = scanner.nextLine();
                    Messaggio resp = inviaRichiesta(new Messaggio("login", new String[]{user, pass}));
                    Object contenuto = resp.getContenuto();
                    if (contenuto instanceof Utenti utente) {
                        System.out.println("Login riuscito! Benvenuto, " + utente.getUserId());
                        usernameLoggato = utente.getUserId();
                    } else {
                        System.out.println("Login fallito: " + contenuto);
                    }
                }
                case 2 -> {
                    System.out.print("Nome: ");
                    String nome = scanner.nextLine();
                    System.out.print("Cognome: ");
                    String cognome = scanner.nextLine();
                    System.out.print("Codice Fiscale: ");
                    String cf = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Username: ");
                    String user = scanner.nextLine();
                    System.out.print("Password: ");
                    String pass = scanner.nextLine();
                    Messaggio resp = inviaRichiesta(new Messaggio("registrazione", new String[]{nome, cognome, cf, email, user, pass}));
                    System.out.println("Esito registrazione: " + resp.getContenuto());
                }
                case 3, 4, 5 -> {
                    System.out.print(scelta == 3 ? "Titolo: " : "Autore: ");
                    String primo = scanner.nextLine();
                    Object richiesta = (scelta == 5) ? new Object[]{primo, Integer.parseInt(scanner.nextLine())} : primo;
                    String tipo = (scelta == 3) ? "ricerca_titolo" : (scelta == 4) ? "ricerca_autore" : "ricerca_autore_anno";
                    Messaggio resp = inviaRichiesta(new Messaggio(tipo, richiesta));
                    stampaListaRisultati(resp);
                }
                case 6 -> {
                    Messaggio lista = inviaRichiesta(new Messaggio("lista_libri", null));
                    Object contenuto = lista.getContenuto();
                    if (contenuto instanceof List<?> titoli && !titoli.isEmpty()) {
                        for (int i = 0; i < titoli.size(); i++) {
                            System.out.printf("%d. %s%n", i + 1, titoli.get(i));
                        }
                        System.out.print("Scegli il numero del libro: ");
                        int scelta1 = Integer.parseInt(scanner.nextLine()) - 1;
                        if (scelta1 >= 0 && scelta1 < titoli.size()) {
                            String titoloSelezionato = (String) titoli.get(scelta1);
                            Messaggio resp = inviaRichiesta(new Messaggio("visualizza_dettagli", titoloSelezionato));
                            System.out.println(resp.getContenuto());
                        } else {
                            System.out.println("Scelta non valida.");
                        }
                    } else {
                        System.out.println("Nessun libro disponibile.");
                    }
                }
                case 7, 8 -> {
                    System.out.print("Nome libreria: ");
                    String nome = scanner.nextLine();
                    System.out.print("Titolo libro: ");
                    String titolo = scanner.nextLine();
                    String comando = scelta == 7 ? "crea_libreria" : "aggiungi_libro";
                    Object[] dati = scelta == 7 ? new Object[]{nome, usernameLoggato} : new Object[]{usernameLoggato, nome, titolo};
                    Messaggio resp = inviaRichiesta(new Messaggio(comando, dati));
                    System.out.println("Esito: " + resp.getContenuto());
                }
                case 9 -> {
                    System.out.print("Titolo libro: ");
                    String titolo = scanner.nextLine();
                    Messaggio risposta = inviaRichiesta(new Messaggio("cerca_libro", titolo));
                    if (!(risposta.getContenuto() instanceof Integer idLibro) || idLibro == -1) {
                        System.out.println("Libro non trovato.");
                        break;
                    }
                    int[] voti = { chiediVoto("Stile"), chiediVoto("Contenuto"), chiediVoto("Gradevolezza"), chiediVoto("Originalit\u00e0"), chiediVoto("Edizione"), chiediVoto("Voto Finale") };
                    System.out.print("Nota finale: ");
                    String nota = scanner.nextLine();
                    Object[] dati = { usernameLoggato, idLibro, voti[0], voti[1], voti[2], voti[3], voti[4], voti[5], nota };
                    Messaggio resp = inviaRichiesta(new Messaggio("valutazione_libro", dati));
                    System.out.println("Esito: " + resp.getContenuto());
                }
                case 10 -> {
                    System.out.print("Libro letto: ");
                    String letto = scanner.nextLine();
                    System.out.print("Libro suggerito: ");
                    String suggerito = scanner.nextLine();
                    Messaggio resp = inviaRichiesta(new Messaggio("aggiungi_suggerimento", new Object[]{usernameLoggato, letto, suggerito}));
                    System.out.println("Esito: " + resp.getContenuto());
                }
                case 11 -> stampaListaRisultati(inviaRichiesta(new Messaggio("visualizza_suggerimenti", null)));
                case 0 -> {
                    chiudi();
                    return;
                }
                default -> System.out.println("Scelta non valida.");
            }
        }
    }

    private void stampaListaRisultati(Messaggio resp) {
        Object contenuto = resp.getContenuto();
        if (contenuto instanceof List<?> lista) {
            if (lista.isEmpty()) System.out.println("Nessun risultato trovato.");
            else lista.forEach(System.out::println);
        } else if (contenuto instanceof String s) {
            System.out.println("Messaggio dal server: " + s);
        } else {
            System.out.println("Risposta inattesa dal server. Tipo: " + (contenuto == null ? "null" : contenuto.getClass()));
        }
    }

    private int chiediVoto(String categoria) {
        while (true) {
            System.out.print(categoria + ": ");
            try {
                int voto = Integer.parseInt(scanner.nextLine());
                if (voto >= 1 && voto <= 10) return voto;
                System.out.println("Inserisci un valore da 1 a 10.");
            } catch (NumberFormatException e) {
                System.out.println("Inserisci un numero valido.");
            }
        }
    }

    public static void main(String[] args) throws IOException {
        Client client = new Client();
        client.menu();
    }
}