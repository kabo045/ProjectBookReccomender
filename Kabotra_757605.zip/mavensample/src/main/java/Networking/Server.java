/**
 * Classe principale del server che gestisce le connessioni client e inizializza i componenti dell'applicazione.
 * 
 * @author Grampa, Marco, 758701, Varese (System architect)
 * @author Kabotra, Rahul, 757605, Varese (Project manager)
 * @author Morena, Matteo, 756150, Varese (Document & quality manager)
 * @author Colombo, Gianluca, 757634, Varese (Design manager)
 */
package Networking;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import Base.GestioneLibreria;
import Base.GestioneUtenti;
import Base.RepositoryLibri;
import database.ConnessioneDB;

/**
 * Classe Server che implementa la logica principale del server.
 * Gestisce le connessioni in entrata e avvia thread separati per ogni client.
 */
public class Server {
    private GestioneLibreria libreria;
    private GestioneUtenti utenti;
    private RepositoryLibri repository;

    /**
     * Costruttore della classe Server.
     * Inizializza i componenti principali dell'applicazione:
     * - GestioneLibreria
     * - GestioneUtenti
     * - RepositoryLibri
     * 
     * Carica inoltre i dati dei libri dal file "Libri.dati" all'avvio.
     */
    public Server() {
        this.libreria = new GestioneLibreria();
        this.utenti = new GestioneUtenti();
        this.repository = new RepositoryLibri();

        try {
        	String path = "../Libri.dati";
            repository.caricaDaFile(path);
            repository.salvaLibri();
            repository.caricaLibri();
        } catch (Exception e) {
            System.err.println("Errore durante l'inizializzazione del server:");
            e.printStackTrace();
        }
    }

    /**
     * Metodo principale che avvia il server.
     * Crea un ServerSocket in ascolto sulla porta 8999 e accetta connessioni in entrata.
     * Per ogni connessione accettata, crea e avvia un nuovo thread SlaveThread
     * per gestire la comunicazione con il client.
     * 
     * Il server rimane in esecuzione indefinitamente finché non si verifica un errore.
     */
    public void exec() {
        try (ServerSocket serverSocket = new ServerSocket(8999)) {
            System.out.println(" Server avviato sulla porta 8999. In attesa di connessioni...");
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Connessione accettata da " + socket.getInetAddress());
                new SlaveThread(socket, libreria, utenti, repository).start();
            }
        } catch (IOException e) {
            System.err.println("Errore nel server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Punto di ingresso principale dell'applicazione server.
     * Crea un'istanza del Server e ne avvia l'esecuzione.
     * 
     * @param args Argomenti da riga di comando (non utilizzati)
     */
    public static void main(String[] args) {
        ConnessioneDB.setupConnectionParams(); // 👈 IMPORTANTE!
        new Server().exec(); // o avvia il thread
    }

}